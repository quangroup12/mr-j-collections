import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, 
  Send, 
  RefreshCw, 
  ExternalLink, 
  ShoppingBag, 
  ShieldCheck, 
  ArrowLeft, 
  Clock, 
  MessageCircle 
} from 'lucide-react';
import { api } from '../api';
import { BUSINESS_INFO } from '../constants';

export default function CustomerInboxPage({ user, onBackToShop, onViewProduct }) {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [inputText, setInputText] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef(null);

  const loadMessages = async () => {
    try {
      setLoading(true);
      const res = await api.getMessages();
      setMessages(res.messages || []);
      // Mark as read
      await api.markMessagesAsRead();
    } catch (err) {
      console.error('Failed to load messages', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMessages();
    const interval = setInterval(loadMessages, 8000); // Poll for replies
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!inputText.trim() || sending) return;

    try {
      setSending(true);
      const newMsg = await api.sendMessage({
        message: inputText.trim()
      });
      setMessages(prev => [...prev, newMsg]);
      setInputText('');
    } catch (err) {
      alert(err.message || 'Failed to send message');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Navigation & Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-900 pb-5">
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToShop}
              className="p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-zinc-800 transition-colors"
              title="Back to marketplace"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div>
              <h1 className="text-2xl sm:text-3xl font-black uppercase tracking-tight text-white font-sans flex items-center gap-2">
                <span>PERSONAL INBOX</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#e5c158]/20 text-[#e5c158] border border-[#e5c158]/40">
                  Direct Line
                </span>
              </h1>
              <p className="text-xs text-zinc-400">
                Logged in as <strong className="text-white">{user?.name || user?.username}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={loadMessages}
              className="p-2 text-zinc-400 hover:text-white bg-zinc-900 rounded-xl border border-zinc-800 transition-colors"
              title="Refresh messages"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>

            <a
              href={BUSINESS_INFO.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/30 text-[#25D366] text-xs font-bold rounded-lg transition-all"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp Us</span>
            </a>
          </div>
        </div>

        {/* Chat Window Container */}
        <div className="rounded-3xl bg-[#111116] border border-zinc-800 shadow-2xl flex flex-col h-[650px] overflow-hidden">
          
          {/* Top Chat Bar */}
          <div className="p-4 bg-zinc-950/80 border-b border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 rounded-xl overflow-hidden border border-[#c5a059] bg-black p-0.5 shrink-0">
                <img src="/logo.jpg" alt="" className="w-full h-full object-cover rounded-lg" />
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-black"></span>
              </div>
              <div>
                <h3 className="text-xs font-black uppercase text-white tracking-wider flex items-center gap-1.5">
                  <span>Mr. J Collections Team</span>
                  <ShieldCheck className="w-3.5 h-3.5 text-[#e5c158]" />
                </h3>
                <p className="text-[10px] text-zinc-400">
                  Tarkwa, Ghana • Active Support
                </p>
              </div>
            </div>

            <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 px-2.5 py-1 rounded-full">
              Connected
            </span>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-[#e5c158]">
                  <MessageSquare className="w-7 h-7" />
                </div>
                <h4 className="text-sm font-black uppercase text-white tracking-wider">
                  No Messages Yet
                </h4>
                <p className="text-xs text-zinc-400 max-w-sm leading-relaxed">
                  Have a question about sneakers, wigs, sizing, or delivery to your city? Send us a message below or click "Ask About Product" on any marketplace item!
                </p>
              </div>
            ) : (
              messages.map((msg) => {
                const isMe = msg.senderRole === 'customer';
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1`}
                  >
                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 px-1">
                      {isMe ? 'You' : msg.senderName} • {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>

                    <div
                      className={`max-w-[85%] sm:max-w-md rounded-2xl p-4 shadow-md space-y-2 ${
                        isMe
                          ? 'bg-gradient-to-br from-zinc-800 to-zinc-900 text-white border border-zinc-700 rounded-tr-xs'
                          : 'bg-[#18181f] text-zinc-100 border border-[#c5a059]/40 rounded-tl-xs'
                      }`}
                    >
                      {/* Attached Product Reference */}
                      {msg.productId && (
                        <div 
                          onClick={() => onViewProduct && onViewProduct({ id: msg.productId, name: msg.productName, price: msg.productPrice })}
                          className="flex items-center gap-3 p-2.5 rounded-xl bg-black/60 border border-zinc-700/80 cursor-pointer hover:border-[#e5c158] transition-colors"
                        >
                          {msg.productImage && (
                            <img
                              src={msg.productImage}
                              alt=""
                              className="w-11 h-11 object-cover rounded-lg border border-zinc-800"
                            />
                          )}
                          <div className="min-w-0 flex-1">
                            <p className="text-[10px] text-zinc-400 font-bold uppercase">Product Inquiry:</p>
                            <p className="text-xs font-bold text-white truncate">{msg.productName}</p>
                            {msg.productPrice && (
                              <p className="text-[11px] font-black text-[#e5c158]">GH₵ {msg.productPrice.toLocaleString()}</p>
                            )}
                          </div>
                          <ExternalLink className="w-3.5 h-3.5 text-zinc-400" />
                        </div>
                      )}

                      {/* Text Message */}
                      <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-line font-medium">
                        {msg.message}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Bottom Chat Input Form */}
          <form onSubmit={handleSend} className="p-3 sm:p-4 bg-zinc-950 border-t border-zinc-800 flex gap-2">
            <input
              type="text"
              required
              placeholder="Type your message or question for Mr. J Collections..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="flex-1 py-3 px-4 bg-zinc-900 border border-zinc-700/80 rounded-xl text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#e5c158] transition-all"
            />
            <button
              type="submit"
              disabled={sending || !inputText.trim()}
              className="py-3 px-5 bg-white hover:bg-[#e5c158] disabled:bg-zinc-800 text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-lg"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">{sending ? 'Sending...' : 'Send'}</span>
            </button>
          </form>

        </div>

      </div>
    </div>
  );
}
