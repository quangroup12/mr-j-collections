import React, { useState, useEffect } from 'react';
import { 
  Package, 
  Users, 
  Flame, 
  Plus, 
  Edit3, 
  Trash2, 
  Search, 
  Filter, 
  Check, 
  X, 
  AlertCircle, 
  Upload, 
  Lock, 
  LogOut, 
  RefreshCw, 
  Eye, 
  Inbox, 
  ChevronRight, 
  CheckCircle2,
  Image as ImageIcon,
  MessageSquare,
  Send,
  ExternalLink,
  MessageCircle
} from 'lucide-react';
import { CATEGORIES, SUBCATEGORIES } from '../constants';
import { api } from '../api';

export default function AdminDashboardPage({ onLogout, onNavigatePublic }) {
  const [activeTab, setActiveTab] = useState('products'); // 'products', 'add', 'password', 'enquiries'
  const [stats, setStats] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [notification, setNotification] = useState(null);

  // Filters for Product Table
  const [tableSearch, setTableSearch] = useState('');
  const [tableCategory, setTableCategory] = useState('All');
  const [tableHotOnly, setTableHotOnly] = useState(false);

  // Add / Edit Product Form State
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    discountPrice: '',
    category: 'Male',
    subcategory: SUBCATEGORIES.Male[0],
    description: '',
    images: [],
    sizesInput: '',
    colorsInput: '',
    stockStatus: 'In Stock',
    hotSelling: false
  });
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [uploadingImages, setUploadingImages] = useState(false);

  // Delete Confirmation Modal State
  const [productToDelete, setProductToDelete] = useState(null);

  // Change Password State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState(null);
  const [passwordError, setPasswordError] = useState(null);

  // Enquiries State
  const [enquiries, setEnquiries] = useState([]);

  // Customer Inbox & Messaging State
  const [threads, setThreads] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [threadMessages, setThreadMessages] = useState([]);
  const [replyText, setReplyText] = useState('');
  const [loadingThread, setLoadingThread] = useState(false);
  const [sendingReply, setSendingReply] = useState(false);
  const [totalUnread, setTotalUnread] = useState(0);

  const loadCustomerThreads = async () => {
    try {
      const res = await api.getMessages();
      const list = res.threads || [];
      setThreads(list);
      const unread = list.reduce((sum, t) => sum + (t.unreadCount || 0), 0);
      setTotalUnread(unread);
      if (list.length > 0 && !selectedUserId) {
        handleSelectThread(list[0].userId);
      }
    } catch (err) {
      console.error('Failed to load threads', err);
    }
  };

  const handleSelectThread = async (userId) => {
    try {
      setSelectedUserId(userId);
      setLoadingThread(true);
      const res = await api.getMessages(userId);
      setSelectedCustomer(res.customer || null);
      setThreadMessages(res.messages || []);
      // Mark as read
      await api.markMessagesAsRead(userId);
      setThreads(prev => prev.map(t => t.userId === userId ? { ...t, unreadCount: 0 } : t));
    } catch (err) {
      console.error('Failed to load thread messages', err);
    } finally {
      setLoadingThread(false);
    }
  };

  const handleSendAdminReply = async (e) => {
    e.preventDefault();
    if (!replyText.trim() || !selectedUserId || sendingReply) return;

    try {
      setSendingReply(true);
      const created = await api.sendMessage({
        userId: selectedUserId,
        message: replyText.trim()
      });
      setThreadMessages(prev => [...prev, created]);
      setReplyText('');
      setThreads(prev => prev.map(t => t.userId === selectedUserId ? {
        ...t,
        lastMessage: created.message,
        lastMessageAt: created.createdAt,
        lastSenderRole: 'admin'
      } : t));
    } catch (err) {
      showNotify(err.message || 'Failed to send reply', 'error');
    } finally {
      setSendingReply(false);
    }
  };

  // Load Dashboard Data
  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [statsRes, prodRes] = await Promise.all([
        api.getAdminStats(),
        api.getProducts()
      ]);
      setStats(statsRes.stats);
      setProducts(prodRes.products || []);
      loadCustomerThreads();
    } catch (err) {
      showNotify(err.message || 'Failed to load dashboard data', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
    const interval = setInterval(loadCustomerThreads, 10000);
    return () => clearInterval(interval);
  }, []);

  // Load Enquiries when that tab is chosen
  useEffect(() => {
    if (activeTab === 'enquiries') {
      api.getEnquiries()
        .then(res => setEnquiries(res.enquiries || []))
        .catch(err => console.error(err));
    } else if (activeTab === 'inbox') {
      loadCustomerThreads();
    }
  }, [activeTab]);

  const showNotify = (message, type = 'success') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Sync subcategory when main category in form changes
  const handleFormCategoryChange = (cat) => {
    const defaultSub = SUBCATEGORIES[cat] ? SUBCATEGORIES[cat][0] : '';
    setFormData(prev => ({
      ...prev,
      category: cat,
      subcategory: defaultSub
    }));
  };

  // Start Adding New Product
  const handleOpenAdd = () => {
    setEditingProduct(null);
    setFormData({
      name: '',
      price: '',
      discountPrice: '',
      category: 'Male',
      subcategory: SUBCATEGORIES.Male[0],
      description: '',
      images: [],
      sizesInput: '',
      colorsInput: '',
      stockStatus: 'In Stock',
      hotSelling: false
    });
    setImageUrlInput('');
    setActiveTab('add');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Start Editing Product
  const handleOpenEdit = (p) => {
    setEditingProduct(p);
    setFormData({
      name: p.name,
      price: p.price.toString(),
      discountPrice: p.discountPrice ? p.discountPrice.toString() : '',
      category: p.category,
      subcategory: p.subcategory,
      description: p.description || '',
      images: p.images || [],
      sizesInput: Array.isArray(p.sizes) ? p.sizes.join(', ') : '',
      colorsInput: Array.isArray(p.colors) ? p.colors.join(', ') : '',
      stockStatus: p.stockStatus || 'In Stock',
      hotSelling: Boolean(p.hotSelling)
    });
    setImageUrlInput('');
    setActiveTab('add');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Upload Local Files
  const handleFileUpload = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    try {
      setUploadingImages(true);
      const urls = await api.uploadImages(files);
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, ...urls]
      }));
      showNotify(`Uploaded ${urls.length} image(s) successfully!`);
    } catch (err) {
      showNotify(err.message || 'Image upload failed', 'error');
    } finally {
      setUploadingImages(false);
      e.target.value = '';
    }
  };

  // Add Image URL
  const handleAddImageUrl = () => {
    if (!imageUrlInput.trim()) return;
    setFormData(prev => ({
      ...prev,
      images: [...prev.images, imageUrlInput.trim()]
    }));
    setImageUrlInput('');
  };

  // Remove Image from Form
  const handleRemoveImage = (indexToRemove) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, idx) => idx !== indexToRemove)
    }));
  };

  // Submit Add / Edit Form
  const handleSaveProduct = async (e) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.price || !formData.category || !formData.subcategory) {
      showNotify('Please fill in Product Name, Price, Category, and Subcategory', 'error');
      return;
    }

    const sizes = formData.sizesInput
      ? formData.sizesInput.split(',').map(s => s.trim()).filter(Boolean)
      : [];

    const colors = formData.colorsInput
      ? formData.colorsInput.split(',').map(c => c.trim()).filter(Boolean)
      : [];

    const payload = {
      name: formData.name.trim(),
      price: parseFloat(formData.price),
      discountPrice: formData.discountPrice ? parseFloat(formData.discountPrice) : null,
      category: formData.category,
      subcategory: formData.subcategory,
      description: formData.description.trim(),
      images: formData.images,
      sizes,
      colors,
      stockStatus: formData.stockStatus,
      hotSelling: formData.hotSelling ? 1 : 0
    };

    try {
      setActionLoading(true);
      if (editingProduct) {
        await api.updateProduct(editingProduct.id, payload);
        showNotify(`Product "${payload.name}" updated successfully!`);
      } else {
        await api.createProduct(payload);
        showNotify(`Product "${payload.name}" uploaded successfully!`);
      }

      await loadDashboardData();
      setActiveTab('products');
    } catch (err) {
      showNotify(err.message || 'Failed to save product', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Quick Toggle Hot Selling directly from Table
  const handleToggleHotSelling = async (p) => {
    try {
      const updatedValue = !p.hotSelling;
      await api.updateProduct(p.id, { hotSelling: updatedValue ? 1 : 0 });
      setProducts(prev => prev.map(item => item.id === p.id ? { ...item, hotSelling: updatedValue } : item));
      setStats(prev => prev ? {
        ...prev,
        hotSelling: updatedValue ? prev.hotSelling + 1 : prev.hotSelling - 1
      } : prev);
      showNotify(`Updated Hot Selling status for ${p.name}`);
    } catch (err) {
      showNotify(err.message || 'Failed to update Hot Selling status', 'error');
    }
  };

  // Quick Toggle Stock Status directly from Table
  const handleToggleStockStatus = async (p) => {
    try {
      const newStatus = p.stockStatus === 'In Stock' ? 'Out of Stock' : 'In Stock';
      await api.updateProduct(p.id, { stockStatus: newStatus });
      setProducts(prev => prev.map(item => item.id === p.id ? { ...item, stockStatus: newStatus } : item));
      showNotify(`Stock updated to ${newStatus} for ${p.name}`);
    } catch (err) {
      showNotify(err.message || 'Failed to update stock status', 'error');
    }
  };

  // Confirm Delete
  const handleConfirmDelete = async () => {
    if (!productToDelete) return;
    try {
      setActionLoading(true);
      await api.deleteProduct(productToDelete.id);
      showNotify(`Deleted "${productToDelete.name}" successfully!`);
      setProductToDelete(null);
      await loadDashboardData();
    } catch (err) {
      showNotify(err.message || 'Failed to delete product', 'error');
    } finally {
      setActionLoading(false);
    }
  };

  // Change Password
  const handleChangePassword = async (e) => {
    e.preventDefault();
    setPasswordMsg(null);
    setPasswordError(null);

    if (newPassword !== confirmPassword) {
      setPasswordError('New passwords do not match!');
      return;
    }

    if (newPassword.length < 6) {
      setPasswordError('New password must be at least 6 characters long.');
      return;
    }

    try {
      setActionLoading(true);
      const res = await api.changePassword(currentPassword, newPassword);
      setPasswordMsg(res.message || 'Password changed successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      setPasswordError(err.message || 'Failed to change password.');
    } finally {
      setActionLoading(false);
    }
  };

  // Filtered Products for the table
  const filteredProducts = products.filter(p => {
    const matchesSearch = tableSearch === '' || 
      p.name.toLowerCase().includes(tableSearch.toLowerCase()) ||
      p.subcategory.toLowerCase().includes(tableSearch.toLowerCase());
    
    const matchesCat = tableCategory === 'All' || p.category === tableCategory;
    const matchesHot = !tableHotOnly || p.hotSelling;

    return matchesSearch && matchesCat && matchesHot;
  });

  return (
    <div className="min-h-screen bg-[#09090b] text-white">
      {/* Top Header Bar */}
      <header className="sticky top-0 z-30 bg-[#101014]/95 backdrop-blur-md border-b border-zinc-800 px-4 sm:px-8 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg overflow-hidden border border-[#c5a059] p-0.5 bg-black">
              <img src="/logo.jpg" alt="Logo" className="w-full h-full object-cover rounded" />
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-black uppercase tracking-wider text-white">
                MR. J <span className="text-[#e5c158]">MANAGEMENT</span>
              </h1>
              <p className="text-[10px] text-zinc-400 uppercase tracking-widest font-semibold">
                Admin Control Center
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
            <button
              onClick={onNavigatePublic}
              className="text-xs font-bold uppercase tracking-wider text-zinc-300 hover:text-white bg-zinc-900 hover:bg-zinc-800 px-3 py-2 rounded-lg border border-zinc-700/80 transition-all flex items-center gap-1.5"
            >
              <Eye className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">View Public Store</span>
            </button>

            <button
              onClick={onLogout}
              className="text-xs font-bold uppercase tracking-wider text-red-400 hover:text-red-300 bg-red-950/40 hover:bg-red-950/70 border border-red-800/40 px-3 py-2 rounded-lg transition-all flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Toast Notification */}
        {notification && (
          <div className={`p-4 rounded-xl border flex items-center gap-3 animate-in fade-in slide-in-from-top duration-300 shadow-xl ${
            notification.type === 'error'
              ? 'bg-red-950/80 border-red-800 text-red-200'
              : 'bg-emerald-950/80 border-emerald-800 text-emerald-200'
          }`}>
            {notification.type === 'error' ? (
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            )}
            <p className="text-xs sm:text-sm font-semibold">{notification.message}</p>
          </div>
        )}

        {/* ============================================================
            OVERVIEW STATS CARDS
        ============================================================ */}
        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            <div className="p-5 rounded-2xl bg-[#121217] border border-zinc-800/80 space-y-2">
              <div className="flex items-center justify-between text-zinc-400">
                <span className="text-[11px] font-bold uppercase tracking-wider">Total Products</span>
                <Package className="w-4 h-4 text-zinc-400" />
              </div>
              <p className="text-3xl font-black text-white">{stats.total}</p>
              <p className="text-[10px] text-zinc-400 font-medium">All store inventory</p>
            </div>

            <div className="p-5 rounded-2xl bg-[#121217] border border-zinc-800/80 space-y-2">
              <div className="flex items-center justify-between text-zinc-400">
                <span className="text-[11px] font-bold uppercase tracking-wider">Male Items</span>
                <span className="text-xs font-bold text-[#e5c158]">M</span>
              </div>
              <p className="text-3xl font-black text-white">{stats.male}</p>
              <p className="text-[10px] text-zinc-400 font-medium">Men's streetwear & kicks</p>
            </div>

            <div className="p-5 rounded-2xl bg-[#121217] border border-zinc-800/80 space-y-2">
              <div className="flex items-center justify-between text-zinc-400">
                <span className="text-[11px] font-bold uppercase tracking-wider">Female Items</span>
                <span className="text-xs font-bold text-pink-400">F</span>
              </div>
              <p className="text-3xl font-black text-white">{stats.female}</p>
              <p className="text-[10px] text-zinc-400 font-medium">Bags, wigs & outfits</p>
            </div>

            <div className="p-5 rounded-2xl bg-[#121217] border border-zinc-800/80 space-y-2">
              <div className="flex items-center justify-between text-zinc-400">
                <span className="text-[11px] font-bold uppercase tracking-wider">Unisex Items</span>
                <span className="text-xs font-bold text-emerald-400">U</span>
              </div>
              <p className="text-3xl font-black text-white">{stats.unisex}</p>
              <p className="text-[10px] text-zinc-400 font-medium">Perfumes, slides & kicks</p>
            </div>

            <div className="col-span-2 sm:col-span-1 p-5 rounded-2xl bg-gradient-to-br from-[#1c1811] to-[#121217] border border-amber-500/30 space-y-2">
              <div className="flex items-center justify-between text-amber-400">
                <span className="text-[11px] font-bold uppercase tracking-wider">Hot Selling</span>
                <Flame className="w-4 h-4 fill-current text-amber-400" />
              </div>
              <p className="text-3xl font-black text-white">{stats.hotSelling}</p>
              <p className="text-[10px] text-amber-400/80 font-medium">Featured on homepage</p>
            </div>
          </div>
        )}

        {/* ============================================================
            NAVIGATION TABS
        ============================================================ */}
        <div className="flex flex-wrap items-center gap-3 border-b border-zinc-800 pb-4">
          <button
            onClick={() => setActiveTab('products')}
            className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 ${
              activeTab === 'products'
                ? 'bg-white text-black shadow-lg'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Product Catalog ({products.length})</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 ${
              activeTab === 'add'
                ? 'bg-[#e5c158] text-black shadow-lg'
                : 'bg-zinc-900 text-[#e5c158] hover:bg-zinc-800 border border-[#e5c158]/30'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>{editingProduct ? 'Edit Product' : 'Add New Product'}</span>
          </button>

          <button
            onClick={() => setActiveTab('password')}
            className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 ${
              activeTab === 'password'
                ? 'bg-white text-black shadow-lg'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>Security & Password</span>
          </button>

          <button
            onClick={() => setActiveTab('inbox')}
            className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 relative ${
              activeTab === 'inbox'
                ? 'bg-white text-black shadow-lg'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            <MessageSquare className="w-4 h-4 text-[#e5c158]" />
            <span>Customer Chats</span>
            {totalUnread > 0 ? (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-red-600 text-white font-black animate-pulse">
                {totalUnread} new
              </span>
            ) : (
              <span className="text-zinc-500 font-normal">({threads.length})</span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('enquiries')}
            className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 ${
              activeTab === 'enquiries'
                ? 'bg-white text-black shadow-lg'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            <Inbox className="w-4 h-4" />
            <span>Contact Enquiries</span>
          </button>

          <button
            onClick={loadDashboardData}
            className="ml-auto p-2.5 text-zinc-400 hover:text-white bg-zinc-900 rounded-xl border border-zinc-800 transition-colors"
            title="Refresh Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* ============================================================
            TAB 1: PRODUCT MANAGEMENT & TABLE
        ============================================================ */}
        {activeTab === 'products' && (
          <div className="space-y-6">
            
            {/* Table Filters & Search */}
            <div className="flex flex-col md:flex-row gap-3 items-center justify-between bg-[#121217] p-4 rounded-2xl border border-zinc-800">
              <div className="relative w-full md:max-w-md">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <input
                  type="text"
                  placeholder="Search products by name or subcategory..."
                  value={tableSearch}
                  onChange={(e) => setTableSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-zinc-900 border border-zinc-700/80 rounded-xl text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#e5c158]"
                />
              </div>

              <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                <select
                  value={tableCategory}
                  onChange={(e) => setTableCategory(e.target.value)}
                  className="bg-zinc-900 border border-zinc-700/80 text-zinc-200 text-xs font-bold uppercase py-2 px-3 rounded-xl focus:outline-none"
                >
                  <option value="All">All Categories</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Unisex">Unisex</option>
                </select>

                <button
                  onClick={() => setTableHotOnly(!tableHotOnly)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1 border transition-all ${
                    tableHotOnly
                      ? 'bg-amber-500 text-black border-amber-400'
                      : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-white'
                  }`}
                >
                  <Flame className="w-3.5 h-3.5" />
                  <span>Hot Only</span>
                </button>

                <button
                  onClick={handleOpenAdd}
                  className="px-4 py-2 bg-[#e5c158] hover:bg-[#d4af37] text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5 shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Product</span>
                </button>
              </div>
            </div>

            {/* Products Table */}
            <div className="bg-[#121217] rounded-2xl border border-zinc-800 overflow-hidden shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-zinc-300">
                  <thead className="bg-zinc-900/90 text-zinc-400 uppercase font-black tracking-widest text-[10px] border-b border-zinc-800">
                    <tr>
                      <th className="py-3.5 px-4">Item</th>
                      <th className="py-3.5 px-4">Category</th>
                      <th className="py-3.5 px-4">Price</th>
                      <th className="py-3.5 px-4 text-center">Hot Selling</th>
                      <th className="py-3.5 px-4 text-center">Stock</th>
                      <th className="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/80">
                    {filteredProducts.length === 0 ? (
                      <tr>
                        <td colSpan="6" className="py-12 text-center text-zinc-500 text-sm">
                          No matching products found in database.
                        </td>
                      </tr>
                    ) : (
                      filteredProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-zinc-900/50 transition-colors">
                          {/* Image & Title */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 rounded-lg overflow-hidden bg-zinc-900 border border-zinc-800 shrink-0">
                                <img
                                  src={p.images && p.images[0] ? p.images[0] : '/logo.jpg'}
                                  alt=""
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="min-w-0">
                                <p className="font-extrabold text-white text-xs truncate max-w-[200px] sm:max-w-xs">
                                  {p.name}
                                </p>
                                <p className="text-[10px] text-zinc-500 truncate">
                                  {p.images?.length || 0} image(s) • {p.subcategory}
                                </p>
                              </div>
                            </div>
                          </td>

                          {/* Category / Subcategory */}
                          <td className="py-3 px-4 whitespace-nowrap">
                            <span className="font-bold text-white uppercase text-[11px] block">{p.category}</span>
                            <span className="text-[10px] text-[#e5c158] block">{p.subcategory}</span>
                          </td>

                          {/* Price */}
                          <td className="py-3 px-4 whitespace-nowrap">
                            <span className="font-black text-white text-sm">GH₵ {p.price.toLocaleString()}</span>
                            {p.discountPrice && (
                              <span className="block text-[10px] text-zinc-500 line-through">
                                GH₵ {p.discountPrice.toLocaleString()}
                              </span>
                            )}
                          </td>

                          {/* Hot Selling Toggle Button */}
                          <td className="py-3 px-4 text-center whitespace-nowrap">
                            <button
                              onClick={() => handleToggleHotSelling(p)}
                              className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider transition-all inline-flex items-center gap-1 ${
                                p.hotSelling
                                  ? 'bg-amber-500 text-black shadow-md'
                                  : 'bg-zinc-800 text-zinc-400 hover:text-white'
                              }`}
                            >
                              <Flame className={`w-3 h-3 ${p.hotSelling ? 'fill-current' : ''}`} />
                              <span>{p.hotSelling ? 'ON' : 'OFF'}</span>
                            </button>
                          </td>

                          {/* Stock Status Toggle Button */}
                          <td className="py-3 px-4 text-center whitespace-nowrap">
                            <button
                              onClick={() => handleToggleStockStatus(p)}
                              className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider transition-all ${
                                p.stockStatus === 'In Stock'
                                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                                  : 'bg-red-950 text-red-400 border border-red-800/60'
                              }`}
                            >
                              {p.stockStatus || 'In Stock'}
                            </button>
                          </td>

                          {/* Action Buttons */}
                          <td className="py-3 px-4 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleOpenEdit(p)}
                                className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white transition-colors"
                                title="Edit Product"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => setProductToDelete(p)}
                                className="p-2 rounded-lg bg-red-950/40 hover:bg-red-900/60 text-red-400 hover:text-red-300 border border-red-800/30 transition-colors"
                                title="Delete Product"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* ============================================================
            TAB 2: ADD / EDIT PRODUCT FORM
        ============================================================ */}
        {activeTab === 'add' && (
          <div className="max-w-4xl mx-auto bg-[#121217] rounded-3xl border border-zinc-800 p-6 sm:p-10 shadow-2xl space-y-8">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <div>
                <h2 className="text-2xl font-black uppercase tracking-tight text-white font-sans">
                  {editingProduct ? 'EDIT PRODUCT' : 'ADD NEW PRODUCT'}
                </h2>
                <p className="text-xs text-zinc-400 mt-1">
                  {editingProduct ? 'Update product details in Mr. J Collections catalog.' : 'Upload a new product with multiple images and specifications.'}
                </p>
              </div>

              <button
                onClick={() => setActiveTab('products')}
                className="text-xs text-zinc-400 hover:text-white uppercase font-bold"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-6">
              
              {/* Product Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                  PRODUCT NAME *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Air Jordan 4 Retro 'Black Gold' High Tops"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                />
              </div>

              {/* Price & Discount Price */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    PRICE (GH₵) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="e.g. 450"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    OPTIONAL ORIGINAL / DISCOUNT PRICE (GH₵)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="e.g. 520 (shows as slashed discount price)"
                    value={formData.discountPrice}
                    onChange={(e) => setFormData({ ...formData, discountPrice: e.target.value })}
                    className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                  />
                </div>
              </div>

              {/* Category & Dynamic Subcategory */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    MAIN CATEGORY *
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => handleFormCategoryChange(e.target.value)}
                    className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    SUBCATEGORY *
                  </label>
                  <select
                    value={formData.subcategory}
                    onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
                    className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                  >
                    {(SUBCATEGORIES[formData.category] || []).map((sub) => (
                      <option key={sub} value={sub}>{sub}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                  DESCRIPTION
                </label>
                <textarea
                  rows={4}
                  placeholder="Describe the fabric, comfort, drip, sillage, or quality..."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158] resize-none"
                ></textarea>
              </div>

              {/* Product Images (Upload or URL) */}
              <div className="space-y-3 p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
                <label className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center justify-between">
                  <span>PRODUCT IMAGES (MULTIPLE IMAGES SUPPORTED)</span>
                  <span className="text-[#e5c158]">{formData.images.length} added</span>
                </label>

                {/* File Upload Trigger */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <label className="flex-1 cursor-pointer py-3 px-4 rounded-xl bg-zinc-900 border-2 border-dashed border-zinc-700 hover:border-[#e5c158] text-center transition-colors">
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                      disabled={uploadingImages}
                    />
                    <div className="flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-wider text-zinc-300">
                      <Upload className="w-4 h-4 text-[#e5c158]" />
                      <span>{uploadingImages ? 'Uploading...' : 'Upload Image Files From Computer'}</span>
                    </div>
                  </label>

                  {/* Add by Image URL option */}
                  <div className="flex-1 flex gap-2">
                    <input
                      type="url"
                      placeholder="Or paste image URL (Unsplash, etc.)"
                      value={imageUrlInput}
                      onChange={(e) => setImageUrlInput(e.target.value)}
                      className="flex-1 py-3 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#e5c158]"
                    />
                    <button
                      type="button"
                      onClick={handleAddImageUrl}
                      className="px-4 py-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold uppercase"
                    >
                      Add URL
                    </button>
                  </div>
                </div>

                {/* Thumbnail list of added images */}
                {formData.images.length > 0 && (
                  <div className="flex flex-wrap gap-3 pt-2">
                    {formData.images.map((img, idx) => (
                      <div key={idx} className="relative w-20 h-20 rounded-xl overflow-hidden border border-zinc-700 group">
                        <img src={img} alt="" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => handleRemoveImage(idx)}
                          className="absolute inset-0 bg-red-950/80 text-red-300 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Sizes & Colors (Optional) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    AVAILABLE SIZES (OPTIONAL)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 40, 41, 42, 43, 44 or M, L, XL"
                    value={formData.sizesInput}
                    onChange={(e) => setFormData({ ...formData, sizesInput: e.target.value })}
                    className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                  />
                  <p className="text-[10px] text-zinc-400">Separate with commas</p>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    AVAILABLE COLORS (OPTIONAL)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Black, Gold, White"
                    value={formData.colorsInput}
                    onChange={(e) => setFormData({ ...formData, colorsInput: e.target.value })}
                    className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                  />
                  <p className="text-[10px] text-zinc-400">Separate with commas</p>
                </div>
              </div>

              {/* Stock Status & Hot Selling Switches */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    STOCK STATUS
                  </label>
                  <select
                    value={formData.stockStatus}
                    onChange={(e) => setFormData({ ...formData, stockStatus: e.target.value })}
                    className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                  >
                    <option value="In Stock">In Stock</option>
                    <option value="Out of Stock">Out of Stock</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    HOT SELLING: ON/OFF
                  </label>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, hotSelling: !formData.hotSelling })}
                    className={`w-full py-3 px-4 rounded-xl text-xs font-black uppercase tracking-wider border flex items-center justify-between transition-all ${
                      formData.hotSelling
                        ? 'bg-amber-500 text-black border-amber-400 shadow-md'
                        : 'bg-zinc-900 text-zinc-400 border-zinc-700/80 hover:text-white'
                    }`}
                  >
                    <span className="flex items-center gap-1.5">
                      <Flame className="w-4 h-4 fill-current" />
                      <span>Display in 🔥 Hot Selling Section</span>
                    </span>
                    <span>{formData.hotSelling ? 'ON' : 'OFF'}</span>
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4 flex gap-4">
                <button
                  type="submit"
                  disabled={actionLoading}
                  className="flex-1 py-4 px-6 bg-[#e5c158] hover:bg-[#d4af37] disabled:bg-zinc-800 text-black font-black text-xs uppercase tracking-[0.2em] rounded-xl transition-all shadow-xl flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  <span>{actionLoading ? 'SAVING...' : (editingProduct ? 'UPDATE PRODUCT' : 'ADD PRODUCT')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('products')}
                  className="py-4 px-6 bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors"
                >
                  Cancel
                </button>
              </div>

            </form>
          </div>
        )}

        {/* ============================================================
            TAB 3: CHANGE ADMIN PASSWORD
        ============================================================ */}
        {activeTab === 'password' && (
          <div className="max-w-md mx-auto bg-[#121217] rounded-3xl border border-zinc-800 p-8 shadow-2xl space-y-6">
            <div>
              <h2 className="text-2xl font-black uppercase tracking-tight text-white font-sans">
                CHANGE PASSWORD
              </h2>
              <p className="text-xs text-zinc-400 mt-1">
                Update the administrator credentials for Mr. J Collections.
              </p>
            </div>

            {passwordMsg && (
              <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{passwordMsg}</span>
              </div>
            )}

            {passwordError && (
              <div className="p-3.5 rounded-xl bg-red-950/40 border border-red-800 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{passwordError}</span>
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                  Current Password *
                </label>
                <input
                  type="password"
                  required
                  placeholder="Enter current password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                  New Password *
                </label>
                <input
                  type="password"
                  required
                  placeholder="At least 6 characters"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                  Confirm New Password *
                </label>
                <input
                  type="password"
                  required
                  placeholder="Re-enter new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-sm focus:outline-none focus:border-[#e5c158]"
                />
              </div>

              <button
                type="submit"
                disabled={actionLoading}
                className="w-full py-3.5 px-6 bg-white hover:bg-[#e5c158] disabled:bg-zinc-800 text-black font-black text-xs uppercase tracking-[0.2em] rounded-xl transition-all shadow-xl"
              >
                {actionLoading ? 'UPDATING...' : 'UPDATE PASSWORD'}
              </button>
            </form>
          </div>
        )}

        {/* ============================================================
            TAB: CUSTOMER INBOX & CHATS
        ============================================================ */}
        {activeTab === 'inbox' && (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-black uppercase text-white font-sans tracking-wide">
                CUSTOMER INBOX & CHAT THREADS
              </h2>
              <p className="text-xs text-zinc-400 mt-1">
                View customer inquiries, questions about products, and reply directly.
              </p>
            </div>

            <div className="rounded-3xl bg-[#121217] border border-zinc-800 shadow-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[620px]">
              
              {/* Left Column: Thread List (4 cols) */}
              <div className="md:col-span-4 border-r border-zinc-800/80 bg-zinc-950/60 flex flex-col">
                <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
                  <span className="text-xs font-black uppercase tracking-wider text-zinc-400">
                    Conversations ({threads.length})
                  </span>
                  <button
                    onClick={loadCustomerThreads}
                    className="p-1.5 text-zinc-500 hover:text-white transition-colors"
                    title="Refresh"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto divide-y divide-zinc-900">
                  {threads.length === 0 ? (
                    <div className="p-8 text-center text-zinc-500 text-xs">
                      No active customer chats yet. When customers click "Ask About Product" or send a message from their inbox, they will appear here.
                    </div>
                  ) : (
                    threads.map((t) => (
                      <button
                        key={t.userId}
                        onClick={() => handleSelectThread(t.userId)}
                        className={`w-full p-4 text-left transition-colors flex items-start gap-3 relative ${
                          selectedUserId === t.userId
                            ? 'bg-zinc-900 border-l-4 border-[#e5c158]'
                            : 'hover:bg-zinc-900/50'
                        }`}
                      >
                        <div className="w-10 h-10 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center font-bold text-white shrink-0">
                          {t.userName ? t.userName[0].toUpperCase() : 'U'}
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="text-xs font-bold text-white truncate">{t.userName}</h4>
                            <span className="text-[10px] text-zinc-500">
                              {new Date(t.lastMessageAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                            </span>
                          </div>

                          <p className="text-[11px] text-zinc-400 truncate mt-0.5">
                            {t.lastSenderRole === 'admin' ? 'You: ' : ''}{t.lastMessage}
                          </p>

                          {t.phone && (
                            <span className="text-[10px] text-[#e5c158] font-medium block mt-0.5">
                              📞 {t.phone}
                            </span>
                          )}
                        </div>

                        {t.unreadCount > 0 && (
                          <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-black">
                            {t.unreadCount}
                          </span>
                        )}
                      </button>
                    ))
                  )}
                </div>
              </div>

              {/* Right Column: Chat Conversation Stream & Reply (8 cols) */}
              <div className="md:col-span-8 flex flex-col bg-[#121217]">
                {selectedUserId && selectedCustomer ? (
                  <>
                    {/* Header */}
                    <div className="p-4 border-b border-zinc-800 bg-zinc-950/80 flex items-center justify-between">
                      <div>
                        <h3 className="text-sm font-black uppercase text-white tracking-wider">
                          {selectedCustomer.name}
                        </h3>
                        <p className="text-[11px] text-zinc-400">
                          @{selectedCustomer.username} • {selectedCustomer.phone || selectedCustomer.email || 'Registered Customer'}
                        </p>
                      </div>

                      {selectedCustomer.phone && (
                        <a
                          href={`https://wa.me/233${selectedCustomer.phone.replace(/^0/, '')}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#25D366]/20 hover:bg-[#25D366]/30 text-[#25D366] text-xs font-bold rounded-lg border border-[#25D366]/40 transition-all"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>Open in WhatsApp</span>
                        </a>
                      )}
                    </div>

                    {/* Chat Messages */}
                    <div className="flex-1 overflow-y-auto p-5 space-y-4 max-h-[460px]">
                      {loadingThread ? (
                        <div className="p-8 text-center text-zinc-500 text-xs">
                          Loading messages...
                        </div>
                      ) : threadMessages.length === 0 ? (
                        <div className="p-8 text-center text-zinc-500 text-xs">
                          No messages in this conversation.
                        </div>
                      ) : (
                        threadMessages.map((msg) => {
                          const isAdmin = msg.senderRole === 'admin';
                          return (
                            <div
                              key={msg.id}
                              className={`flex flex-col ${isAdmin ? 'items-end' : 'items-start'} space-y-1`}
                            >
                              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 px-1">
                                {isAdmin ? 'Store Admin (You)' : selectedCustomer.name} • {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>

                              <div
                                className={`max-w-[85%] sm:max-w-md rounded-2xl p-4 shadow-md space-y-2 ${
                                  isAdmin
                                    ? 'bg-[#1e1c15] text-white border border-[#e5c158]/50 rounded-tr-xs'
                                    : 'bg-zinc-900 text-zinc-200 border border-zinc-800 rounded-tl-xs'
                                }`}
                              >
                                {msg.productId && (
                                  <div className="flex items-center gap-3 p-2.5 rounded-xl bg-black/60 border border-zinc-800">
                                    {msg.productImage && (
                                      <img
                                        src={msg.productImage}
                                        alt=""
                                        className="w-10 h-10 object-cover rounded-lg border border-zinc-800"
                                      />
                                    )}
                                    <div className="min-w-0 flex-1">
                                      <p className="text-[10px] text-[#e5c158] font-bold uppercase">Customer Asked About:</p>
                                      <p className="text-xs font-bold text-white truncate">{msg.productName}</p>
                                      {msg.productPrice && (
                                        <p className="text-[11px] font-black text-white">GH₵ {msg.productPrice.toLocaleString()}</p>
                                      )}
                                    </div>
                                  </div>
                                )}

                                <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-line">
                                  {msg.message}
                                </p>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>

                    {/* Admin Reply Bar */}
                    <form onSubmit={handleSendAdminReply} className="p-4 bg-zinc-950 border-t border-zinc-800 flex gap-2">
                      <input
                        type="text"
                        required
                        placeholder={`Reply directly to ${selectedCustomer.name}...`}
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        className="flex-1 py-3 px-4 bg-zinc-900 border border-zinc-700/80 rounded-xl text-xs sm:text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#e5c158]"
                      />
                      <button
                        type="submit"
                        disabled={sendingReply || !replyText.trim()}
                        className="py-3 px-5 bg-[#e5c158] hover:bg-[#d4af37] disabled:bg-zinc-800 text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-1.5 shadow-md"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>{sendingReply ? 'Sending...' : 'Reply'}</span>
                      </button>
                    </form>
                  </>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-zinc-500 space-y-2">
                    <MessageSquare className="w-12 h-12 text-zinc-700" />
                    <p className="text-sm font-bold uppercase text-zinc-400">Select a Customer Conversation</p>
                    <p className="text-xs text-zinc-500">Pick any thread on the left to review inquiries and send replies.</p>
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

        {/* ============================================================
            TAB 4: CUSTOMER ENQUIRIES
        ============================================================ */}
        {activeTab === 'enquiries' && (
          <div className="space-y-4">
            <h2 className="text-xl font-black uppercase text-white tracking-wide">
              Customer Enquiries From Website
            </h2>
            {enquiries.length === 0 ? (
              <div className="p-12 text-center bg-[#121217] rounded-2xl border border-zinc-800 text-zinc-500">
                No customer enquiry messages submitted yet.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {enquiries.map((enq) => (
                  <div key={enq.id} className="p-6 rounded-2xl bg-[#121217] border border-zinc-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-black text-white text-sm">{enq.name}</span>
                      <span className="text-[10px] text-zinc-500">
                        {new Date(enq.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-xs text-[#e5c158] font-bold">Phone: {enq.phone}</p>
                    <p className="text-xs text-zinc-300 bg-zinc-900/80 p-3 rounded-lg leading-relaxed whitespace-pre-line">
                      "{enq.message}"
                    </p>
                    <div className="pt-2">
                      <a
                        href={`https://wa.me/233${enq.phone.replace(/^0/, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs text-[#25D366] hover:underline"
                      >
                        <span>Reply to customer on WhatsApp →</span>
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </main>

      {/* ============================================================
          DELETE CONFIRMATION MODAL (Strictly as specified)
      ============================================================ */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#16161b] rounded-3xl border border-zinc-700 p-6 sm:p-8 space-y-6 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-12 h-12 rounded-full bg-red-950/60 border border-red-800 text-red-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-lg font-black uppercase text-white">
                Delete Product
              </h3>
              <p className="text-sm text-zinc-300 font-semibold">
                Are you sure you want to delete this product?
              </p>
              <p className="text-xs text-[#e5c158] font-bold">
                "{productToDelete.name}"
              </p>
              <p className="text-xs text-zinc-500">
                This action cannot be undone. It will be permanently removed from the public shop.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setProductToDelete(null)}
                className="py-3 px-4 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-black text-xs uppercase tracking-wider transition-colors"
              >
                CANCEL
              </button>

              <button
                type="button"
                disabled={actionLoading}
                onClick={handleConfirmDelete}
                className="py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs uppercase tracking-wider transition-colors shadow-lg"
              >
                {actionLoading ? 'DELETING...' : 'DELETE'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
