import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  MessageCircle, 
  Flame, 
  Truck, 
  ShieldCheck, 
  RotateCcw, 
  Check, 
  Share2, 
  ShoppingBag,
  ExternalLink,
  MessageSquare
} from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { BUSINESS_INFO, createOrderWhatsAppUrl, createEnquiryWhatsAppUrl } from '../constants';
import { api } from '../api';

export default function ProductDetailsPage({ 
  productId, 
  onBack, 
  onViewProduct,
  onAddToCart,
  onAskProduct
}) {
  const [product, setProduct] = useState(null);
  const [related, setRelated] = useState([]);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState(null);
  const [selectedColor, setSelectedColor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      try {
        setLoading(true);
        setError(null);
        const res = await api.getProductById(productId);
        if (isMounted) {
          setProduct(res.product);
          setRelated(res.related || []);
          setSelectedImage(0);

          // Pre-select first size/color if available
          if (res.product.sizes && res.product.sizes.length > 0) {
            setSelectedSize(res.product.sizes[0]);
          } else {
            setSelectedSize(null);
          }

          if (res.product.colors && res.product.colors.length > 0) {
            setSelectedColor(res.product.colors[0]);
          } else {
            setSelectedColor(null);
          }
        }
      } catch (err) {
        if (isMounted) setError(err.message || 'Product not found');
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadData();
    window.scrollTo({ top: 0, behavior: 'smooth' });

    return () => {
      isMounted = false;
    };
  }, [productId]);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0c] text-white flex items-center justify-center py-20">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 border-4 border-zinc-700 border-t-[#e5c158] rounded-full animate-spin mx-auto"></div>
          <p className="text-xs uppercase tracking-widest text-zinc-400">Loading Product Details...</p>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-[#0a0a0c] text-white py-20 px-4">
        <div className="max-w-md mx-auto text-center space-y-4 bg-zinc-900/60 p-8 rounded-2xl border border-zinc-800">
          <p className="text-red-400 font-semibold">{error || 'Product not found'}</p>
          <button
            onClick={onBack}
            className="px-6 py-2.5 bg-white text-black font-bold uppercase text-xs rounded-full"
          >
            Back to Marketplace
          </button>
        </div>
      </div>
    );
  }

  const images = product.images && product.images.length > 0
    ? product.images
    : ['https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1000&q=80'];

  const currentImage = images[selectedImage] || images[0];
  const isOutOfStock = product.stockStatus === 'Out of Stock';

  // Buy Now WhatsApp link with prefilled format
  const orderWhatsAppUrl = createOrderWhatsAppUrl(product, selectedSize, selectedColor);
  const enquiryWhatsAppUrl = createEnquiryWhatsAppUrl(`Hello Mr. J Collections, I would like to ask a question about: ${product.name}`);

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Navigation Breadcrumb / Back button */}
        <div className="flex items-center justify-between border-b border-zinc-900 pb-4">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-zinc-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Shop</span>
          </button>

          <button
            onClick={handleShare}
            className="inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white bg-zinc-900 px-3 py-1.5 rounded-lg border border-zinc-800 transition-colors"
            title="Copy link"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copiedLink ? 'Link Copied!' : 'Share'}</span>
          </button>
        </div>

        {/* ============================================================
            MAIN PRODUCT PRESENTATION (Nike Editorial Showcase)
        ============================================================ */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 xl:gap-14">
          
          {/* LEFT: Image Gallery (7 cols on LG) */}
          <div className="lg:col-span-7 space-y-4">
            {/* Primary Large Image Frame */}
            <div className="relative aspect-[4/5] sm:aspect-square md:aspect-[4/3] lg:aspect-[4/5] w-full rounded-2xl overflow-hidden bg-zinc-950 border border-zinc-800/80 shadow-2xl">
              <img
                src={currentImage}
                alt={product.name}
                className="w-full h-full object-cover object-center"
              />

              {/* Badges Over Primary Image */}
              <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
                {product.hotSelling && (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-gradient-to-r from-amber-500 to-yellow-400 text-black shadow-lg">
                    <Flame className="w-3.5 h-3.5 fill-current" />
                    HOT SELLING
                  </span>
                )}
                {product.discountPrice && product.discountPrice > product.price && (
                  <span className="inline-block px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-red-600 text-white shadow-lg">
                    SAVE GH₵ {(product.discountPrice - product.price).toLocaleString()}
                  </span>
                )}
              </div>

              {isOutOfStock && (
                <div className="absolute inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-20">
                  <div className="text-center p-6 bg-zinc-900 border border-zinc-700 rounded-xl">
                    <p className="text-sm font-black uppercase tracking-widest text-zinc-300">
                      Currently Out of Stock
                    </p>
                    <p className="text-xs text-zinc-500 mt-1">
                      Message us on WhatsApp to check next restock date.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Thumbnail Selectors (if multiple images) */}
            {images.length > 1 && (
              <div className="flex items-center gap-3 overflow-x-auto pb-2">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`relative w-20 h-20 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${
                      selectedImage === idx
                        ? 'border-[#e5c158] scale-105 shadow-md'
                        : 'border-zinc-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* RIGHT: Product Details & Purchase CTA (5 cols on LG) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div className="space-y-6">
              
              {/* Category & Status */}
              <div className="flex items-center justify-between text-xs font-bold uppercase tracking-widest text-zinc-400">
                <span className="text-[#e5c158]">{product.category} • {product.subcategory}</span>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] ${
                  isOutOfStock 
                    ? 'bg-red-950/60 text-red-400 border border-red-800/40' 
                    : 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/40'
                }`}>
                  {product.stockStatus || 'In Stock'}
                </span>
              </div>

              {/* Title */}
              <h1 className="text-3xl sm:text-4xl font-black uppercase tracking-tight text-white font-sans leading-tight">
                {product.name}
              </h1>

              {/* Price Block */}
              <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 flex items-baseline gap-3">
                <span className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                  GH₵ {product.price.toLocaleString()}
                </span>
                {product.discountPrice && product.discountPrice > product.price && (
                  <span className="text-base text-zinc-500 line-through">
                    GH₵ {product.discountPrice.toLocaleString()}
                  </span>
                )}
                <span className="ml-auto text-[11px] text-zinc-400 font-semibold uppercase tracking-wider">
                  Ghana Cedi
                </span>
              </div>

              {/* Sizes Selection (if available) */}
              {product.sizes && product.sizes.length > 0 && (
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-zinc-300">
                    <span>Available Sizes:</span>
                    {selectedSize && <span className="text-[#e5c158]">Selected: {selectedSize}</span>}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setSelectedSize(sz)}
                        className={`min-w-12 py-2 px-3.5 rounded-lg text-xs font-black uppercase tracking-wider border transition-all ${
                          selectedSize === sz
                            ? 'bg-white text-black border-white shadow-md'
                            : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Colors Selection (if available) */}
              {product.colors && product.colors.length > 0 && (
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-zinc-300">
                    <span>Available Colors:</span>
                    {selectedColor && <span className="text-[#e5c158]">Selected: {selectedColor}</span>}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {product.colors.map((clr) => (
                      <button
                        key={clr}
                        onClick={() => setSelectedColor(clr)}
                        className={`py-2 px-4 rounded-lg text-xs font-black uppercase tracking-wider border transition-all ${
                          selectedColor === clr
                            ? 'bg-[#e5c158] text-black border-[#e5c158] shadow-md'
                            : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                        }`}
                      >
                        {clr}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Description */}
              <div className="space-y-2 pt-2 border-t border-zinc-900">
                <h4 className="text-xs font-black uppercase tracking-widest text-zinc-400">
                  Product Description
                </h4>
                <p className="text-sm text-zinc-300 leading-relaxed whitespace-pre-line font-normal">
                  {product.description || 'High quality fashion item from Mr. J Collections in Tarkwa. Verified for original drip and comfort.'}
                </p>
              </div>

              {/* Delivery & Ordering Notice */}
              <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800/80 space-y-2 text-xs text-zinc-400">
                <div className="flex items-center gap-2 text-white font-bold uppercase tracking-wider">
                  <Truck className="w-4 h-4 text-[#e5c158]" />
                  <span>Nationwide Ghana Delivery</span>
                </div>
                <p className="leading-relaxed">
                  We deliver directly to Accra, Kumasi, Takoradi, Sunyani, Tamale, Cape Coast, and all regions across Ghana.
                </p>
              </div>

            </div>

            {/* ============================================================
                CART, INBOX & WHATSAPP BUTTONS
            ============================================================ */}
            <div className="space-y-3 pt-4 border-t border-zinc-800">
              
              {/* Add to Shopping Cart Button */}
              {onAddToCart && (
                <button
                  type="button"
                  onClick={() => onAddToCart(product, selectedSize, selectedColor)}
                  disabled={isOutOfStock}
                  className="w-full py-4 px-6 bg-[#e5c158] hover:bg-[#d4af37] disabled:opacity-50 text-black font-black text-sm uppercase tracking-[0.2em] rounded-full shadow-xl transition-all duration-300 transform active:scale-95 flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="w-5 h-5 fill-current" />
                  <span>ADD TO SHOPPING CART</span>
                </button>
              )}

              {/* Ask About Product Button */}
              {onAskProduct && (
                <button
                  type="button"
                  onClick={() => onAskProduct(product)}
                  className="w-full py-3.5 px-6 bg-zinc-900 hover:bg-zinc-800 border border-[#e5c158]/50 text-white font-black text-xs uppercase tracking-[0.15em] rounded-full transition-all flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-4 h-4 text-[#e5c158]" />
                  <span>ASK ABOUT THIS PRODUCT (INBOX)</span>
                </button>
              )}

              {/* Primary Buy Now WhatsApp Button */}
              <a
                href={orderWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-4 px-6 bg-white hover:bg-zinc-200 text-black font-black text-sm uppercase tracking-[0.2em] rounded-full shadow-2xl transition-all duration-300 transform active:scale-95 flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-5 h-5 fill-current text-[#25D366]" />
                <span>BUY NOW VIA WHATSAPP</span>
              </a>

              {/* Secondary Chat on WhatsApp Button */}
              <a
                href={enquiryWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-6 bg-[#25D366] hover:bg-[#20ba59] text-black font-extrabold text-xs uppercase tracking-[0.15em] rounded-full shadow-lg transition-all flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>CHAT ON WHATSAPP (0594326515)</span>
              </a>

              <p className="text-[11px] text-center text-zinc-400">
                🔒 Add to cart to bundle multiple items, or buy instantly on WhatsApp.
              </p>
            </div>

          </div>

        </div>

        {/* ============================================================
            RELATED PRODUCTS
        ============================================================ */}
        {related.length > 0 && (
          <div className="space-y-6 pt-12 border-t border-zinc-900">
            <div className="flex items-center justify-between">
              <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-white font-sans">
                You May Also Like
              </h3>
              <span className="text-xs text-[#e5c158] uppercase tracking-widest font-bold">
                More in {product.category}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {related.map((item) => (
                <ProductCard
                  key={item.id}
                  product={item}
                  onViewDetails={onViewProduct}
                />
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
