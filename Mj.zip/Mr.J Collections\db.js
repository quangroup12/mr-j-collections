const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');

const dbPath = path.join(__dirname, 'database.sqlite');
const db = new Database(dbPath);

// Enable WAL mode for better concurrency and performance
db.pragma('journal_mode = WAL');

// Initialize database schema
function initDB() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      passwordHash TEXT NOT NULL,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price REAL NOT NULL,
      discountPrice REAL,
      category TEXT NOT NULL,
      subcategory TEXT NOT NULL,
      description TEXT,
      images TEXT NOT NULL, -- JSON array of image URLs
      sizes TEXT,          -- JSON array or comma separated
      colors TEXT,         -- JSON array or comma separated
      stockStatus TEXT DEFAULT 'In Stock',
      hotSelling INTEGER DEFAULT 0,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS enquiries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      message TEXT NOT NULL,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      username TEXT UNIQUE NOT NULL,
      phone TEXT,
      email TEXT,
      passwordHash TEXT NOT NULL,
      role TEXT DEFAULT 'customer',
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
      updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER NOT NULL,
      senderRole TEXT NOT NULL, -- 'customer' or 'admin'
      senderName TEXT NOT NULL,
      productId INTEGER,
      productName TEXT,
      productPrice REAL,
      productImage TEXT,
      message TEXT NOT NULL,
      isRead INTEGER DEFAULT 0,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Seed default admin if not exists
  const existingAdmin = db.prepare('SELECT * FROM admins WHERE username = ?').get('Joe123collections');
  if (!existingAdmin) {
    const defaultPasswordHash = bcrypt.hashSync('Joe123collections', 10);
    db.prepare('INSERT INTO admins (username, passwordHash) VALUES (?, ?)').run('Joe123collections', defaultPasswordHash);
    console.log('✅ Default admin account seeded: Joe123collections');
  }

  // Also ensure admin exists in users table with role 'admin'
  const existingUserAdmin = db.prepare('SELECT * FROM users WHERE username = ?').get('Joe123collections');
  if (!existingUserAdmin) {
    const defaultPasswordHash = bcrypt.hashSync('Joe123collections', 10);
    db.prepare('INSERT INTO users (name, username, passwordHash, role) VALUES (?, ?, ?, ?)').run(
      'Mr. J Store Admin',
      'Joe123collections',
      defaultPasswordHash,
      'admin'
    );
    console.log('✅ Admin user account seeded into users table: Joe123collections');
  }

  // Seed initial high-quality curated products if table is empty
  const count = db.prepare('SELECT COUNT(*) as count FROM products').get().count;
  if (count === 0) {
    seedCuratedProducts();
  }
}

function seedCuratedProducts() {
  const seedList = [
    {
      name: "Air Jordan 4 Retro 'Black Gold' High Tops",
      price: 650,
      discountPrice: 720,
      category: "Unisex",
      subcategory: "Sneakers",
      description: "Iconic silhouette engineered with premium nubuck leather, gold eyelet accents, and responsive Air-Sole cushioning. The ultimate street drip for fashion connoisseurs in Ghana.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["40", "41", "42", "43", "44", "45"]),
      colors: JSON.stringify(["Black/Metallic Gold", "Triple Black"]),
      stockStatus: "In Stock",
      hotSelling: 1
    },
    {
      name: "Yeezy Slide Pure Onyx Edition",
      price: 280,
      discountPrice: 320,
      category: "Male",
      subcategory: "Slides",
      description: "Injected EVA foam offers lightweight durability and cloud-like comfort. Minimalist design paired with deep horizontal tread grooves for superior traction on any street.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1603808033192-082d6919d3e1?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["41", "42", "43", "44", "45"]),
      colors: JSON.stringify(["Matte Onyx", "Sand Beige"]),
      stockStatus: "In Stock",
      hotSelling: 1
    },
    {
      name: "Baccarat Rouge 540 Eau de Parfum Extrait",
      price: 450,
      discountPrice: 500,
      category: "Unisex",
      subcategory: "Perfumes",
      description: "Luminous and sophisticated. Breezes of jasmine, radiant saffron, ambergris mineral notes, and freshly-cut cedar. Long-lasting sillage guaranteed to turn heads all day.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["70ml", "100ml"]),
      colors: JSON.stringify(["Gold Amber"]),
      stockStatus: "In Stock",
      hotSelling: 1
    },
    {
      name: "Oversized Heavyweight Graphic Drip T-Shirt",
      price: 180,
      discountPrice: 220,
      category: "Male",
      subcategory: "Plain T-Shirts",
      description: "280 GSM luxury combed cotton with drop-shoulder fit and high rib collar. Breathable, retains shape wash after wash, perfect everyday streetwear.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["M", "L", "XL", "XXL"]),
      colors: JSON.stringify(["Vintage Washed Black", "Crisp White"]),
      stockStatus: "In Stock",
      hotSelling: 1
    },
    {
      name: "Luxury Quilted Chain Leather Handbag",
      price: 390,
      discountPrice: 450,
      category: "Female",
      subcategory: "Handbags",
      description: "Exquisite diamond-pattern quilted lambskin vegan leather with high-grade electroplated gold chain hardware. Interior zip compartments and magnetic flap lock.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["Medium (26cm)"]),
      colors: JSON.stringify(["Obsidian Black", "Cream Champagne"]),
      stockStatus: "In Stock",
      hotSelling: 1
    },
    {
      name: "HD Frontal Deep Wave Human Hair Wig (28 inches)",
      price: 850,
      discountPrice: 950,
      category: "Female",
      subcategory: "Wigs",
      description: "100% Raw unprocessed virgin human hair with invisible HD lace frontal. Pre-plucked natural hairline, baby hairs, tangle-free and heat stylable up to 400°F.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["26 inch", "28 inch", "30 inch"]),
      colors: JSON.stringify(["Natural Black #1B", "Honey Blonde Highlights"]),
      stockStatus: "In Stock",
      hotSelling: 1
    },
    {
      name: "Skeleton Automatic Luxury Steel Wristwatch",
      price: 520,
      discountPrice: 590,
      category: "Unisex",
      subcategory: "Wristwatch",
      description: "Precision automatic mechanical movement with transparent exhibition dial, scratch-resistant sapphire crystal glass, and solid 316L stainless steel bracelet.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["42mm Case"]),
      colors: JSON.stringify(["Black & Gold", "Silver Royal"]),
      stockStatus: "In Stock",
      hotSelling: 1
    },
    {
      name: "Retro Thick Acetate Square Sunglasses",
      price: 150,
      discountPrice: 190,
      category: "Unisex",
      subcategory: "Sunglasses",
      description: "Bold geometric unisex frames with 100% UV400 polarized black lenses and gold temple accents. Provides maximum glare protection with celebrity drip.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1572635196237-14b3f281503f?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["Standard Fits All"]),
      colors: JSON.stringify(["Glossy Jet Black", "Tortoiseshell Brown"]),
      stockStatus: "In Stock",
      hotSelling: 0
    },
    {
      name: "Tactical Matte Black Streetwear Cross Bag",
      price: 195,
      discountPrice: 240,
      category: "Male",
      subcategory: "Cross Bag",
      description: "Water-repellent Cordura nylon cross body chest rig bag. Features quick-release tactical buckle, weatherproof zippers, and multi-compartment storage for phone, keys, and wallet.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["Compact 2.5L"]),
      colors: JSON.stringify(["Stealth Black"]),
      stockStatus: "In Stock",
      hotSelling: 0
    },
    {
      name: "Distressed Slim Fit Streetwear Denim Jeans",
      price: 320,
      discountPrice: 380,
      category: "Male",
      subcategory: "Jeans",
      description: "Premium heavy-stretch cotton denim with handcrafted distressing, knee rips, and branded hardware. Tailored taper at the ankles to showcase your sneakers.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1542272604-780c96856592?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1582552938357-32b906df40cb?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["30", "32", "34", "36", "38"]),
      colors: JSON.stringify(["Washed Indigo Blue", "Faded Charcoal"]),
      stockStatus: "In Stock",
      hotSelling: 0
    },
    {
      name: "Satin Reversible Silk Hair Bonnet (Jumbo)",
      price: 85,
      discountPrice: 110,
      category: "Female",
      subcategory: "Hair Bonnets",
      description: "Double-layered premium mulberry silk satin bonnet with adjustable tie band. Retains hair moisture, prevents breakage, and protects wigs and braids all night.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["Extra Large Jumbo"]),
      colors: JSON.stringify(["Gold / Black", "Rose Gold / Champagne"]),
      stockStatus: "In Stock",
      hotSelling: 0
    },
    {
      name: "18K Gold Plated Cuban Link Chain & Bracelet Set",
      price: 360,
      discountPrice: 420,
      category: "Male",
      subcategory: "Chain/Bracelet",
      description: "Heavy 12mm Miami Cuban link necklace (22 inches) with matching 8.5 inch bracelet. Triple PVD vacuum-plated with 18-karat real gold over solid stainless steel. Non-tarnish and waterproof.",
      images: JSON.stringify([
        "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1000&q=80",
        "https://images.unsplash.com/photo-1611591475152-4735492d3f54?auto=format&fit=crop&w=1000&q=80"
      ]),
      sizes: JSON.stringify(["22 Inch Chain + 8.5 Inch Bracelet"]),
      colors: JSON.stringify(["Yellow Gold", "Iced White Gold"]),
      stockStatus: "In Stock",
      hotSelling: 1
    }
  ];

  const stmt = db.prepare(`
    INSERT INTO products (name, price, discountPrice, category, subcategory, description, images, sizes, colors, stockStatus, hotSelling)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  for (const item of seedList) {
    stmt.run(
      item.name,
      item.price,
      item.discountPrice,
      item.category,
      item.subcategory,
      item.description,
      item.images,
      item.sizes,
      item.colors,
      item.stockStatus,
      item.hotSelling
    );
  }
  console.log(`✅ Seeded ${seedList.length} premium initial products into SQLite!`);
}

module.exports = {
  db,
  initDB
};
