import React, { useState, useEffect } from 'react';
import { Search, Filter, Flame, ArrowUpDown, X, AlertCircle } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { CATEGORIES, SUBCATEGORIES } from '../constants';
import { api } from '../api';

export default function ShopPage({ 
  initialCategory = 'All', 
  initialSubcategory = 'All', 
  initialHotOnly = false,
  initialSearch = '',
  onViewProduct,
  onAddToCart,
  onAskProduct
}) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters State
  const [selectedCategory, setSelectedCategory] = useState(initialCategory || 'All');
  const [selectedSubcategory, setSelectedSubcategory] = useState(initialSubcategory || 'All');
  const [hotSellingOnly, setHotSellingOnly] = useState(initialHotOnly || false);
  const [searchQuery, setSearchQuery] = useState(initialSearch || '');
  const [sortBy, setSortBy] = useState('newest');

  // Reset or adjust subcategory when main category changes
  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    setSelectedSubcategory('All');
  };

  // Fetch products whenever filters or sorting changes
  useEffect(() => {
    let isMounted = true;
    async function fetchFiltered() {
      try {
        setLoading(true);
        setError(null);

        const res = await api.getProducts({
          category: selectedCategory,
          subcategory: selectedSubcategory,
          hotSelling: hotSellingOnly,
          search: searchQuery,
          sort: sortBy
        });

        if (isMounted) {
          setProducts(res.products || []);
        }
      } catch (err) {
        if (isMounted) {
          setError(err.message || 'Failed to load products');
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    const timer = setTimeout(() => {
      fetchFiltered();
    }, 250); // Debounce search

    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [selectedCategory, selectedSubcategory, hotSellingOnly, searchQuery, sortBy]);

  // Available subcategories based on current selectedCategory
  const currentSubcategories = selectedCategory !== 'All' 
    ? (SUBCATEGORIES[selectedCategory] || [])
    : [];

  const handleResetFilters = () => {
    setSelectedCategory('All');
    setSelectedSubcategory('All');
    setHotSellingOnly(false);
    setSearchQuery('');
    setSortBy('newest');
  };

  const hasActiveFilters = selectedCategory !== 'All' || selectedSubcategory !== 'All' || hotSellingOnly || searchQuery !== '';

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Page Title & Breadcrumb header */}
        <div className="space-y-2 border-b border-zinc-900 pb-6">
          <div className="flex items-center text-xs font-bold uppercase tracking-widest text-[#e5c158]">
            <span>The Official Collection</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-sans">
            MR. J MARKETPLACE
          </h1>
          <p className="text-zinc-400 text-sm max-w-xl">
            Explore authentic Ghanaian streetwear, sneakers, perfumes, wigs, and luxury accessories with nationwide delivery.
          </p>
        </div>

        {/* ============================================================
            SEARCH & SORT CONTROLS
        ============================================================ */}
        <div className="bg-[#121216] border border-zinc-800 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            
            {/* Search Bar */}
            <div className="relative w-full md:max-w-md">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
              <input
                type="text"
                placeholder="Search sneakers, slides, perfumes, bags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-9 py-2.5 bg-zinc-900 border border-zinc-700/80 rounded-xl text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#e5c158] transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Sort & Quick Hot Selling Toggle */}
            <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
              {/* Hot Selling Switch */}
              <button
                onClick={() => setHotSellingOnly(!hotSellingOnly)}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all border ${
                  hotSellingOnly
                    ? 'bg-amber-500 text-black border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)]'
                    : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <Flame className={`w-3.5 h-3.5 ${hotSellingOnly ? 'fill-current' : 'text-amber-500'}`} />
                <span>Hot Selling</span>
              </button>

              {/* Sort By Dropdown */}
              <div className="flex items-center gap-2">
                <ArrowUpDown className="w-4 h-4 text-zinc-400 hidden sm:inline" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="bg-zinc-900 border border-zinc-700/80 text-zinc-200 text-xs font-bold uppercase tracking-wider py-2.5 px-3 rounded-xl focus:outline-none focus:border-[#e5c158]"
                >
                  <option value="newest">Sort: Newest</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="name-asc">Name: A to Z</option>
                </select>
              </div>
            </div>

          </div>

          {/* ============================================================
              MAIN CATEGORY TABS
          ============================================================ */}
          <div className="pt-2 border-t border-zinc-800/80 flex flex-wrap items-center gap-2">
            <span className="text-xs font-black uppercase tracking-widest text-zinc-500 mr-2 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              Category:
            </span>

            {['All', ...CATEGORIES].map((category) => (
              <button
                key={category}
                onClick={() => handleCategoryChange(category)}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all border ${
                  selectedCategory === category
                    ? 'bg-white text-black border-white shadow-md'
                    : 'bg-zinc-900/80 text-zinc-400 border-zinc-800 hover:text-white hover:border-zinc-700'
                }`}
              >
                {category}
              </button>
            ))}

            {hasActiveFilters && (
              <button
                onClick={handleResetFilters}
                className="ml-auto text-xs text-zinc-400 hover:text-[#e5c158] underline underline-offset-4 flex items-center gap-1"
              >
                <X className="w-3 h-3" />
                <span>Reset All Filters</span>
              </button>
            )}
          </div>

          {/* ============================================================
              DYNAMIC SUBCATEGORY PILLS (when category is selected)
          ============================================================ */}
          {currentSubcategories.length > 0 && (
            <div className="pt-2 border-t border-zinc-800/60 flex flex-wrap items-center gap-1.5">
              <span className="text-[11px] font-bold uppercase tracking-widest text-zinc-500 mr-2">
                Subcategory:
              </span>
              <button
                onClick={() => setSelectedSubcategory('All')}
                className={`px-3 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider transition-all ${
                  selectedSubcategory === 'All'
                    ? 'bg-[#e5c158] text-black font-black'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800 border border-zinc-800'
                }`}
              >
                All {selectedCategory}
              </button>
              {currentSubcategories.map((sub) => (
                <button
                  key={sub}
                  onClick={() => setSelectedSubcategory(sub)}
                  className={`px-3 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider transition-all ${
                    selectedSubcategory === sub
                      ? 'bg-[#e5c158] text-black font-black shadow-sm'
                      : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800 border border-zinc-800'
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ============================================================
            PRODUCT LIST GRID / EMPTY STATE
        ============================================================ */}
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6 py-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
              <div key={n} className="bg-zinc-900/60 rounded-xl h-84 animate-pulse border border-zinc-800"></div>
            ))}
          </div>
        ) : error ? (
          <div className="p-8 text-center bg-red-950/20 border border-red-800/50 rounded-2xl text-red-300 space-y-3">
            <AlertCircle className="w-8 h-8 mx-auto text-red-400" />
            <p className="font-semibold">{error}</p>
            <button
              onClick={() => handleResetFilters()}
              className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg text-xs font-bold"
            >
              Reload All Products
            </button>
          </div>
        ) : products.length === 0 ? (
          <div className="py-20 text-center bg-zinc-900/30 rounded-2xl border border-zinc-800 space-y-4">
            <div className="h-16 w-16 mx-auto rounded-full bg-zinc-800 flex items-center justify-center text-zinc-500">
              <Search className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-black uppercase text-white tracking-wider">
              No Products Found
            </h3>
            <p className="text-zinc-400 text-sm max-w-md mx-auto">
              We couldn't find any products matching your selected category, subcategory or search term.
            </p>
            <button
              onClick={handleResetFilters}
              className="px-6 py-2.5 bg-white hover:bg-[#e5c158] text-black font-black text-xs uppercase tracking-widest rounded-full transition-all"
            >
              Clear All Filters
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-zinc-400 uppercase tracking-widest font-semibold px-1">
              <span>Showing {products.length} Products</span>
              {selectedCategory !== 'All' && (
                <span className="text-[#e5c158]">{selectedCategory} Collection</span>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onViewDetails={onViewProduct}
                  onAddToCart={onAddToCart}
                  onAskProduct={onAskProduct}
                />
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
