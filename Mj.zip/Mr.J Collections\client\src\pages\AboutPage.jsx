import React from 'react';
import { ShieldCheck, Tag, Truck, MessageCircle, MapPin, CheckCircle2, ArrowRight } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

export default function AboutPage({ onNavigateShop }) {
  const pillars = [
    {
      icon: ShieldCheck,
      title: "QUALITY",
      description: "We focus on bringing customers quality fashion products.",
      detail: "Every sneaker, slide, perfume oil, handbag, and wig is rigorously inspected before dispatch to ensure you receive only original drip and durable craftsmanship."
    },
    {
      icon: Tag,
      title: "AFFORDABLE PRICES",
      description: "Fashion should look good without being unnecessarily expensive.",
      detail: "We believe premium drip should be accessible. Our prices in Ghana Cedi are kept competitive so students, professionals, and tastemakers can dress luxuriously within budget."
    },
    {
      icon: Truck,
      title: "NATIONWIDE DELIVERY",
      description: "Customers across Ghana can order from Mr. J Collections.",
      detail: "From our flagship hub in Tarkwa, we ship swiftly across all 16 regions — including Greater Accra, Ashanti, Western, Central, Eastern, Volta, and Northern Ghana."
    },
    {
      icon: MessageCircle,
      title: "CUSTOMER SERVICE",
      description: "Customers can contact us directly through WhatsApp for orders and enquiries.",
      detail: "Experience 1-on-1 personalized assistance. Chat directly with us on 0594326515 to confirm sizes, check live photos, receive payment details, and track your package."
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-20">
        
        {/* ============================================================
            ABOUT HEADER & EXACT TEXT
        ============================================================ */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-zinc-900 border border-[#c5a059]/40 text-[#e5c158] text-xs font-black uppercase tracking-widest">
              <span>About Mr. J Collections</span>
            </div>

            <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-sans leading-none">
              YOUR TRUSTED <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-200 to-[#e5c158]">
                FASHION PLUG
              </span> <br />
              IN TARKWA, GHANA.
            </h1>

            {/* Exact required About Us paragraph */}
            <div className="p-6 rounded-2xl bg-[#121217] border-l-4 border-[#e5c158] border-y border-r border-zinc-800 shadow-xl">
              <p className="text-base sm:text-lg text-zinc-200 font-medium leading-relaxed">
                {BUSINESS_INFO.aboutUsText}
              </p>
            </div>

            <div className="flex flex-wrap gap-4 pt-2">
              <button
                onClick={onNavigateShop}
                className="px-8 py-3.5 bg-white hover:bg-[#e5c158] text-black font-black text-xs uppercase tracking-widest rounded-full transition-all flex items-center gap-2"
              >
                <span>EXPLORE THE COLLECTION</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href={BUSINESS_INFO.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="px-7 py-3.5 bg-[#25D366] hover:bg-[#20ba59] text-black font-black text-xs uppercase tracking-widest rounded-full transition-all flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>CHAT ON WHATSAPP</span>
              </a>
            </div>

          </div>

          {/* Right: Gold Emblem Brand Visual */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-72 h-72 sm:w-96 sm:h-96 rounded-3xl overflow-hidden border border-[#c5a059]/40 bg-zinc-950 p-3 shadow-[0_0_60px_rgba(229,193,88,0.2)]">
              <img
                src="/logo.jpg"
                alt="Mr. J Collections Gold Bag Logo"
                className="w-full h-full object-cover rounded-2xl"
              />
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-black/80 backdrop-blur-md border border-zinc-800 text-center">
                <p className="text-xs font-black uppercase tracking-widest text-[#e5c158]">
                  Mr. J Collections
                </p>
                <p className="text-[11px] text-zinc-400">Tarkwa • Ghana</p>
              </div>
            </div>
          </div>
        </div>

        {/* ============================================================
            CORE PILLARS SECTION (QUALITY, AFFORDABLE, NATIONWIDE, SERVICE)
        ============================================================ */}
        <div className="space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <p className="text-xs font-black uppercase tracking-[0.25em] text-[#e5c158]">
              What Defines Us
            </p>
            <h2 className="text-3xl sm:text-4xl font-black uppercase tracking-tight text-white font-sans">
              THE MR. J PILLARS
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {pillars.map((pillar, idx) => {
              const Icon = pillar.icon;
              return (
                <div 
                  key={idx}
                  className="p-8 rounded-2xl bg-[#111115] border border-zinc-800 hover:border-[#c5a059]/50 transition-all duration-300 shadow-xl space-y-4 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-zinc-700/80 flex items-center justify-center text-[#e5c158] group-hover:scale-110 group-hover:bg-[#e5c158] group-hover:text-black transition-all">
                    <Icon className="w-6 h-6" />
                  </div>

                  <h3 className="text-xl font-black uppercase tracking-wider text-white">
                    {pillar.title}
                  </h3>

                  <p className="text-sm font-semibold text-[#e5c158]">
                    {pillar.description}
                  </p>

                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed font-normal">
                    {pillar.detail}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* ============================================================
            LOCATION & DISPATCH HUB
        ============================================================ */}
        <div className="rounded-3xl bg-zinc-950 border border-zinc-800/80 p-8 sm:p-12 text-center space-y-6">
          <div className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-widest text-[#e5c158]">
            <MapPin className="w-4 h-4" />
            <span>Rooted in Tarkwa, Serving All of Ghana</span>
          </div>

          <h3 className="text-2xl sm:text-4xl font-black uppercase text-white font-sans">
            Ready to upgrade your drip?
          </h3>

          <p className="max-w-xl mx-auto text-sm text-zinc-400 leading-relaxed">
            Reach out directly on WhatsApp at <strong className="text-white">0594326515</strong> or follow us on social media <strong className="text-white">@mr.j.collections</strong>.
          </p>

          <div className="pt-2">
            <button
              onClick={onNavigateShop}
              className="px-10 py-4 bg-white hover:bg-[#e5c158] text-black font-black text-xs uppercase tracking-[0.2em] rounded-full transition-all shadow-xl"
            >
              SHOP OUR MARKETPLACE
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
