import React, { useState } from 'react';
import { createEnquiryWhatsAppUrl } from '../constants';

export default function FloatingWhatsApp() {
  const [hovered, setHovered] = useState(false);
  const whatsappUrl = createEnquiryWhatsAppUrl();

  return (
    <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3">
      {/* Tooltip Badge */}
      <div 
        className={`hidden sm:flex items-center gap-2 bg-zinc-950/90 text-white text-xs font-semibold py-1.5 px-3 rounded-full border border-zinc-700 shadow-xl transition-all duration-300 ${
          hovered ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4 pointer-events-none'
        }`}
      >
        <span className="h-2 w-2 rounded-full bg-[#25D366] animate-pulse"></span>
        <span>Order on WhatsApp (0594326515)</span>
      </div>

      {/* Floating Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        className="relative group flex items-center justify-center w-14 h-14 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-full shadow-2xl hover:shadow-[0_0_25px_rgba(37,211,102,0.6)] transform hover:scale-110 active:scale-95 transition-all duration-300 focus:outline-none"
        aria-label="Chat on WhatsApp with Mr. J Collections"
      >
        {/* Radar ping effect */}
        <span className="absolute -inset-1 rounded-full bg-[#25D366] opacity-30 group-hover:opacity-60 animate-ping pointer-events-none"></span>

        {/* Official WhatsApp SVG Icon */}
        <svg 
          className="w-8 h-8 fill-current drop-shadow-md" 
          viewBox="0 0 24 24"
        >
          <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.598 2.669-.699c.983.54 1.81.819 2.791.82h.005c3.181 0 5.767-2.587 5.768-5.766 0-3.18-2.586-5.766-5.768-5.766zm9.969 5.766c0 5.518-4.482 10-10 10-1.745 0-3.385-.45-4.821-1.241l-5.179 1.356 1.378-5.039c-.878-1.493-1.378-3.235-1.378-5.076 0-5.518 4.482-10 10-10s10 4.482 10 10zm-6.286 3.197c-.201-.1-.703-.346-1.127-.558-.423-.213-.732-.32-.988.067-.255.387-.514.773-.63 1.031-.115.259-.23.292-.432.191s-1.488-.548-2.835-1.748c-1.047-.934-1.755-2.088-1.96-2.441-.207-.353-.022-.544.079-.644.091-.091.203-.236.305-.353s.135-.203.203-.338c.068-.135.034-.254-.017-.356-.051-.102-.458-1.103-.628-1.51-.165-.397-.333-.343-.458-.349-.118-.006-.254-.008-.39-.008s-.356.051-.542.254c-.186.203-.712.695-.712 1.695s.729 1.966.83 2.102c.102.136 1.434 2.19 3.475 3.07.485.209.864.334 1.159.428.487.155.93.133 1.28.081.39-.058 1.196-.489 1.365-.961.169-.472.169-.876.118-.961-.05-.084-.186-.135-.387-.236z" />
        </svg>

        {/* Small Active Green Indicator on mobile */}
        <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-emerald-400 border-2 border-[#0a0a0c] rounded-full"></span>
      </a>
    </div>
  );
}
