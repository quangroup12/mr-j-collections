import React, { useState } from 'react';
import { X, Send, MessageSquare, AlertCircle, CheckCircle2, Lock, ArrowRight, MessageCircle } from 'lucide-react';
import { api } from '../api';
import { createEnquiryWhatsAppUrl } from '../constants';

export default function AskProductModal({ 
  isOpen, 
  onClose, 
  product, 
  user, 
  onRequireAuth, 
  onMessageSent 
}) {
  if (!isOpen || !product) return null;

  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  const primaryImage = product.images && product.images.length > 0 ? product.images[0] : '/logo.jpg';

  const handleSend = async (e) => {
    e.preventDefault();
    if (!message.trim()) return;

    if (!user) {
      onRequireAuth();
      return;
    }

    try {
      setLoading(true);
      setError(null);
      await api.sendMessage({
        message: message.trim(),
        productId: product.id,
        productName: product.name,
        productPrice: product.price,
        productImage: primaryImage
      });

      setSuccess(true);
      setMessage('');
      if (onMessageSent) onMessageSent();
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1800);
    } catch (err) {
      setError(err.message || 'Failed to send question');
    } finally {
      setLoading(false);
    }
  };

  const whatsappInquiryUrl = createEnquiryWhatsAppUrl(
    `Hello Mr. J Collections, I want to inquire about: ${product.name} (GH₵ ${product.price}). Is this in stock?`
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
      <div className="w-full max-w-lg bg-[#141419] rounded-3xl border border-zinc-800 shadow-2xl p-6 sm:p-8 space-y-6 animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-zinc-900 border border-zinc-700 text-[#e5c158]">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black uppercase text-white tracking-wider">
                Ask About Product
              </h3>
              <p className="text-[11px] text-zinc-400">
                Direct conversation with Mr. J Collections
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Product Reference Card */}
        <div className="flex items-center gap-3.5 p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800">
          <img
            src={primaryImage}
            alt={product.name}
            className="w-14 h-16 object-cover rounded-xl border border-zinc-800"
          />
          <div className="min-w-0 flex-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#e5c158]">
              {product.category} • {product.subcategory}
            </span>
            <h4 className="text-xs font-bold text-white truncate">
              {product.name}
            </h4>
            <p className="text-xs font-black text-white mt-0.5">
              GH₵ {product.price.toLocaleString()}
            </p>
          </div>
        </div>

        {/* Success Banner */}
        {success && (
          <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <p className="font-bold uppercase tracking-wider">Sent to Your Personal Inbox!</p>
              <p className="text-emerald-400">Our team has received your inquiry and will reply shortly.</p>
            </div>
          </div>
        )}

        {/* Error Banner */}
        {error && (
          <div className="p-3.5 rounded-xl bg-red-950/50 border border-red-800 text-red-300 text-xs flex items-center gap-2.5">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* If user is not logged in */}
        {!user ? (
          <div className="space-y-4 py-2">
            <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 text-center space-y-3">
              <Lock className="w-6 h-6 text-[#e5c158] mx-auto" />
              <div>
                <h4 className="text-xs font-black uppercase tracking-wider text-white">
                  Login or Sign Up to Message Store
                </h4>
                <p className="text-xs text-zinc-400 max-w-sm mx-auto mt-1">
                  Create an account or sign in to track replies in your personal inbox.
                </p>
              </div>

              <button
                onClick={() => {
                  onClose();
                  onRequireAuth();
                }}
                className="w-full py-3 px-5 bg-white hover:bg-[#e5c158] text-black font-black text-xs uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2"
              >
                <span>LOGIN / SIGN UP</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="text-center">
              <span className="text-xs text-zinc-500">or ask instantly without logging in:</span>
              <div className="pt-2">
                <a
                  href={whatsappInquiryUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 bg-[#25D366] hover:bg-[#20ba59] text-black font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>Ask Directly on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        ) : (
          /* Form for Logged In Customer */
          <form onSubmit={handleSend} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                Your Question / Message:
              </label>
              <textarea
                rows={4}
                required
                placeholder="e.g. Do you have this available in size 42? How long does delivery to Kumasi take?"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white text-xs placeholder-zinc-500 focus:outline-none focus:border-[#e5c158] transition-all resize-none"
              ></textarea>
            </div>

            <div className="flex gap-3">
              <button
                type="submit"
                disabled={loading || !message.trim()}
                className="flex-1 py-3.5 px-6 bg-white hover:bg-[#e5c158] disabled:bg-zinc-800 text-black font-black text-xs uppercase tracking-[0.2em] rounded-xl transition-all shadow-xl flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>{loading ? 'SENDING...' : 'SEND TO ADMIN INBOX'}</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="py-3.5 px-5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-xl text-xs font-bold uppercase"
              >
                Cancel
              </button>
            </div>

            <p className="text-[11px] text-zinc-500 text-center">
              💬 Responses will appear right inside your <strong>Personal Inbox</strong>.
            </p>
          </form>
        )}

      </div>
    </div>
  );
}
