export const BUSINESS_INFO = {
  name: "Mr. J Collections",
  location: "Tarkwa, Ghana",
  delivery: "Nationwide delivery across Ghana",
  phone: "0594326515",
  whatsappNumber: "233594326515",
  whatsappLink: "https://wa.me/233594326515",
  socialMedia: "@mr.j.collections",
  socialMediaUrl: "https://instagram.com/mr.j.collections",
  aboutUsText: "Mr. J Collections is your trusted fashion plug in Tarkwa. We sell quality and affordable male, female and unisex fashion items. We bring you original drip - from sneakers, slides, perfumes, bags, wigs and more. Quality, affordable, fast delivery across Ghana."
};

export const CATEGORIES = ["Male", "Female", "Unisex"];

export const SUBCATEGORIES = {
  Male: [
    "Boxers & Singlets",
    "Slides",
    "Sneakers",
    "Plain T-Shirts",
    "Jeans",
    "Shorts",
    "Face Caps",
    "Belt",
    "Cross Bag",
    "Perfume Oil",
    "Chain/Bracelet"
  ],
  Female: [
    "Slides",
    "Sneakers",
    "Handbags",
    "Perfume/Body Mist",
    "Wigs",
    "Hair Bonnets",
    "Lip Gloss/Makeup",
    "Short Gowns",
    "Tops & Leggings",
    "Underwear Set",
    "Jewelry Set",
    "Sunglasses"
  ],
  Unisex: [
    "Perfumes",
    "Slides",
    "Sneakers",
    "Wristwatch",
    "Sunglasses",
    "Caps",
    "T-Shirts"
  ]
};

// Category cards background imagery for Home Page
export const CATEGORY_CARD_IMAGES = {
  Male: "https://images.unsplash.com/photo-1516257984-b1b4d707412e?auto=format&fit=crop&w=1200&q=80",
  Female: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1200&q=80",
  Unisex: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=1200&q=80"
};

// WhatsApp Order Link Generator
export function createOrderWhatsAppUrl(product, size = null, color = null) {
  let message = `Hello Mr. J Collections, I want to order:\n\nProduct: ${product.name}\nPrice: GH₵ ${product.price}`;
  if (size) message += `\nSize: ${size}`;
  if (color) message += `\nColor: ${color}`;
  message += `\n\nPlease send me the payment details and delivery information.`;

  return `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

// WhatsApp General Enquiry Link
export function createEnquiryWhatsAppUrl(customMessage = null) {
  const message = customMessage || "Hello Mr. J Collections, I would like to make an enquiry.";
  return `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(message)}`;
}
