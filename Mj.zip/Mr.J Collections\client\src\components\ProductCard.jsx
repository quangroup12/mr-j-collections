import React from 'react';
import { Eye, MessageCircle, Flame, ArrowRight, ShoppingBag, MessageSquare, Plus } from 'lucide-react';
import { createOrderWhatsAppUrl } from '../constants';

export default function ProductCard({ 
  product, 
  onViewDetails, 
  onAddToCart, 
  onAskProduct 
}) {
  // Primary image
  const primaryImage = product.images && product.images.length > 0
    ? product.images[0]
    : '/logo.jpg';

  // Buy Now WhatsApp link
  const whatsappUrl = createOrderWhatsAppUrl(product);
  const isOutOfStock = product.stockStatus === 'Out of Stock';

  return (
    <div className="group relative bg-[#131316] rounded-xl overflow-hidden border border-zinc-800/80 hover:border-[#c5a059]/60 shadow-lg hover:shadow-2xl transition-all duration-300 flex flex-col">
      {/* Image Container with Badges */}
      <div 
        onClick={() => onViewDetails(product)}
        className="relative w-full aspect-[4/5] bg-zinc-900 overflow-hidden cursor-pointer"
      >
        <img
          src={primaryImage}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
        />

        {/* Dark Gradient Overlay for text contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none"></div>

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {product.hotSelling && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-amber-500 to-yellow-400 text-black shadow-md">
              <Flame className="w-3 h-3 fill-current" />
              HOT SELLING
            </span>
          )}
          {product.discountPrice && product.discountPrice > product.price && (
            <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-red-600 text-white shadow-md">
              SALE
            </span>
          )}
        </div>

        {/* Stock Status Badge if Out of Stock */}
        {isOutOfStock && (
          <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-10">
            <span className="px-4 py-1.5 bg-zinc-800/90 border border-zinc-600 text-zinc-300 rounded text-xs font-bold uppercase tracking-widest">
              Out of Stock
            </span>
          </div>
        )}

        {/* Quick action buttons on hover */}
        <div className="absolute bottom-3 right-3 flex items-center gap-1.5 z-20 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
          {onAskProduct && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAskProduct(product);
              }}
              className="p-2 rounded-full bg-black/80 hover:bg-[#e5c158] text-white hover:text-black transition-colors shadow-lg"
              title="Ask About Product"
            >
              <MessageSquare className="w-3.5 h-3.5" />
            </button>
          )}

          {onAddToCart && !isOutOfStock && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAddToCart(product);
              }}
              className="p-2 rounded-full bg-black/80 hover:bg-[#e5c158] text-white hover:text-black transition-colors shadow-lg"
              title="Add to Shopping Cart"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails(product);
            }}
            className="p-2 rounded-full bg-black/80 hover:bg-white text-white hover:text-black transition-colors shadow-lg"
            title="View Details"
          >
            <Eye className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Product Content Details */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* Category & Subcategory line */}
          <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
            <span>{product.category}</span>
            <span className="text-zinc-600">•</span>
            <span className="text-[#e5c158] truncate max-w-[130px]">{product.subcategory}</span>
          </div>

          {/* Product Title */}
          <h3 
            onClick={() => onViewDetails(product)}
            className="text-sm sm:text-base font-extrabold text-white group-hover:text-[#e5c158] transition-colors line-clamp-2 cursor-pointer leading-snug"
          >
            {product.name}
          </h3>
        </div>

        {/* Pricing & Actions */}
        <div className="space-y-3 pt-1">
          <div className="flex items-baseline justify-between">
            <div className="flex items-baseline gap-2">
              <span className="text-lg sm:text-xl font-black text-white tracking-tight">
                GH₵ {product.price.toLocaleString()}
              </span>
              {product.discountPrice && product.discountPrice > product.price && (
                <span className="text-xs text-zinc-500 line-through">
                  GH₵ {product.discountPrice.toLocaleString()}
                </span>
              )}
            </div>

            {onAskProduct && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onAskProduct(product);
                }}
                className="text-[11px] font-bold text-zinc-400 hover:text-[#e5c158] transition-colors flex items-center gap-1"
                title="Ask question about this product"
              >
                <MessageSquare className="w-3 h-3 text-[#e5c158]" />
                <span>Ask</span>
              </button>
            )}
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            {onAddToCart ? (
              <button
                onClick={() => onAddToCart(product)}
                disabled={isOutOfStock}
                className="w-full py-2 px-2 text-[11px] font-black uppercase tracking-wider text-zinc-200 hover:text-white bg-zinc-800/90 hover:bg-zinc-700 disabled:opacity-50 rounded-lg transition-colors flex items-center justify-center gap-1"
              >
                <ShoppingBag className="w-3.5 h-3.5 text-[#e5c158]" />
                <span>+ Cart</span>
              </button>
            ) : (
              <button
                onClick={() => onViewDetails(product)}
                className="w-full py-2 px-2 text-[11px] font-bold uppercase tracking-wider text-zinc-300 hover:text-white bg-zinc-800/90 hover:bg-zinc-700 rounded-lg transition-colors flex items-center justify-center gap-1"
              >
                <span>Details</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2 px-2 text-[11px] font-black uppercase tracking-wider bg-white hover:bg-[#e5c158] text-black rounded-lg transition-all flex items-center justify-center gap-1 shadow-md"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-current" />
              <span>Buy Now</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
