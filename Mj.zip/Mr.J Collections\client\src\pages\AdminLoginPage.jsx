import React, { useState } from 'react';
import { Lock, User, Eye, EyeOff, ShieldCheck, ArrowRight, AlertCircle } from 'lucide-react';
import { api } from '../api';

export default function AdminLoginPage({ onLoginSuccess, onCancel }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Please provide both username and password.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await api.login(username, password);
      if (res.success) {
        onLoginSuccess(res.user);
      }
    } catch (err) {
      setError(err.message || 'Invalid username or password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] bg-[#0a0a0c] flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md space-y-8">
        
        {/* Brand Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex p-3 rounded-2xl bg-zinc-900 border border-[#c5a059]/40 shadow-xl">
            <img src="/logo.jpg" alt="Logo" className="w-12 h-12 object-cover rounded-xl" />
          </div>

          <h2 className="text-2xl sm:text-3xl font-black uppercase tracking-wider text-white font-sans">
            Admin Portal
          </h2>
          <p className="text-xs uppercase tracking-widest text-zinc-500 font-semibold">
            Mr. J Collections • Management Login
          </p>
        </div>

        {/* Card */}
        <div className="p-8 rounded-3xl bg-[#121217] border border-zinc-800 shadow-2xl space-y-6">
          {error && (
            <div className="p-3.5 rounded-xl bg-red-950/50 border border-red-800 text-red-300 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Username */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                Admin Username
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <input
                  type="text"
                  required
                  placeholder="Enter admin username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-zinc-900 border border-zinc-700/80 rounded-xl text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#e5c158] transition-all"
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Enter password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-3 bg-zinc-900 border border-zinc-700/80 rounded-xl text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#e5c158] transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 px-6 bg-white hover:bg-[#e5c158] disabled:bg-zinc-800 text-black font-black text-xs uppercase tracking-[0.2em] rounded-xl shadow-xl transition-all duration-300 flex items-center justify-center gap-2 transform active:scale-95"
            >
              <span>{loading ? 'AUTHENTICATING...' : 'ACCESS DASHBOARD'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick info note */}
          <div className="pt-2 text-center border-t border-zinc-900">
            <button
              onClick={onCancel}
              className="text-xs text-zinc-500 hover:text-zinc-300 transition-colors uppercase tracking-wider font-semibold"
            >
              ← Return to Public Website
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
