import React from 'react';
import { ArrowRight, MessageCircle, Flame, Tag, ShieldCheck, Truck, Clock, CheckCircle2 } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { BUSINESS_INFO, CATEGORY_CARD_IMAGES, SUBCATEGORIES } from '../constants';

export default function HomePage({ 
  hotSellingProducts, 
  loadingHotSelling, 
  onNavigateShop, 
  onCategorySelect, 
  onViewProduct,
  onAddToCart,
  onAskProduct
}) {
  const categoriesList = [
    {
      id: 'Male',
      title: 'MALE COLLECTION',
      subtitle: 'Premium Streetwear & Drip',
      image: CATEGORY_CARD_IMAGES.Male,
      items: SUBCATEGORIES.Male.slice(0, 7).join(' • ') + ' & more',
    },
    {
      id: 'Female',
      title: 'FEMALE COLLECTION',
      subtitle: 'Luxury Bags, Wigs & Outfits',
      image: CATEGORY_CARD_IMAGES.Female,
      items: SUBCATEGORIES.Female.slice(0, 7).join(' • ') + ' & more',
    },
    {
      id: 'Unisex',
      title: 'UNISEX ESSENTIALS',
      subtitle: 'Signature Fragrances, Kicks & Watches',
      image: CATEGORY_CARD_IMAGES.Unisex,
      items: SUBCATEGORIES.Unisex.join(' • '),
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white">
      {/* ============================================================
          HERO SECTION (Nike Official Aesthetic)
      ============================================================ */}
      <section className="relative min-h-[85vh] lg:min-h-[90vh] flex items-center justify-center overflow-hidden px-4 sm:px-6 lg:px-8 border-b border-zinc-900">
        {/* Background image */}
        <div className="absolute inset-0 z-0">
          <img
            src="/hero-bg.jpg"
            alt="Mr. J Collections Fashion"
            className="w-full h-full object-cover object-center opacity-50 filter brightness-75"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0c] via-[#0a0a0c]/60 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0c]/60 via-transparent to-[#0a0a0c]/60"></div>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-5xl mx-auto text-center space-y-6 sm:space-y-8 py-16">
          
          {/* Subtle Tagline / Location Pill */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-zinc-900/90 border border-[#c5a059]/40 backdrop-blur-md shadow-lg">
            <span className="h-2 w-2 rounded-full bg-[#e5c158]"></span>
            <span className="text-xs sm:text-sm font-bold uppercase tracking-[0.2em] text-zinc-300">
              Tarkwa's Trusted Fashion Plug • Nationwide Ghana Delivery
            </span>
          </div>

          {/* Nike-Style Bold Headline */}
          <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black uppercase tracking-tight text-white leading-none font-sans">
            YOUR STYLE. <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-200 to-[#e5c158]">
              YOUR DRIP.
            </span> <br className="hidden sm:inline" />
            YOUR COLLECTION.
          </h1>

          {/* Description */}
          <p className="max-w-2xl mx-auto text-base sm:text-lg md:text-xl text-zinc-300 font-normal leading-relaxed">
            Quality and affordable fashion for everyone. Shop sneakers, slides, perfumes, bags, wigs and more from <span className="text-white font-semibold">Mr. J Collections</span>.
          </p>

          {/* Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={() => onNavigateShop()}
              className="w-full sm:w-auto px-9 py-4 bg-white hover:bg-[#e5c158] text-black font-black text-sm uppercase tracking-[0.2em] rounded-full shadow-2xl transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2"
            >
              <span>SHOP NOW</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <a
              href={BUSINESS_INFO.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-8 py-4 bg-[#25D366] hover:bg-[#20ba59] text-black font-black text-sm uppercase tracking-[0.2em] rounded-full shadow-xl transition-all duration-300 transform hover:-translate-y-0.5 flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5 fill-current" />
              <span>CHAT ON WHATSAPP</span>
            </a>
          </div>

          {/* Quick Highlight Tickers */}
          <div className="pt-8 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto text-left">
            <div className="flex items-center gap-2.5 p-3 rounded-lg bg-zinc-900/50 border border-zinc-800/60">
              <Truck className="w-5 h-5 text-[#e5c158] shrink-0" />
              <div className="text-xs">
                <p className="font-bold text-white uppercase">Nationwide</p>
                <p className="text-zinc-400">Fast delivery in Ghana</p>
              </div>
            </div>
            <div className="flex items-center gap-2.5 p-3 rounded-lg bg-zinc-900/50 border border-zinc-800/60">
              <ShieldCheck className="w-5 h-5 text-[#e5c158] shrink-0" />
              <div className="text-xs">
                <p className="font-bold text-white uppercase">Original Drip</p>
                <p className="text-zinc-400">100% Quality checked</p>
              </div>
            </div>
            <div className="flex items-center gap-2.5 p-3 rounded-lg bg-zinc-900/50 border border-zinc-800/60">
              <MessageCircle className="w-5 h-5 text-[#25D366] shrink-0" />
              <div className="text-xs">
                <p className="font-bold text-white uppercase">Instant Order</p>
                <p className="text-zinc-400">Direct WhatsApp plug</p>
              </div>
            </div>
            <div className="flex items-center gap-2.5 p-3 rounded-lg bg-zinc-900/50 border border-zinc-800/60">
              <Tag className="w-5 h-5 text-[#e5c158] shrink-0" />
              <div className="text-xs">
                <p className="font-bold text-white uppercase">Affordable</p>
                <p className="text-zinc-400">Student & street friendly</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* ============================================================
          CATEGORY SECTION
      ============================================================ */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-2">
          <p className="text-xs font-black uppercase tracking-[0.25em] text-[#e5c158]">
            Curated For Every Style
          </p>
          <h2 className="text-3xl sm:text-5xl font-black uppercase tracking-tight text-white font-sans">
            EXPLORE CATEGORIES
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base">
            Select a collection to browse hand-picked fashion essentials curated in Tarkwa.
          </p>
        </div>

        {/* 3 Large Category Showcase Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {categoriesList.map((cat) => (
            <div 
              key={cat.id}
              className="group relative rounded-2xl overflow-hidden bg-zinc-900 border border-zinc-800 hover:border-[#c5a059] shadow-2xl transition-all duration-500 flex flex-col justify-end min-h-[480px] p-6 sm:p-8"
            >
              {/* Background Image with Dark Vignette */}
              <div className="absolute inset-0 z-0">
                <img
                  src={cat.image}
                  alt={cat.title}
                  className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-black/20 group-hover:via-black/50 transition-colors"></div>
              </div>

              {/* Card Information */}
              <div className="relative z-10 space-y-4">
                <span className="inline-block px-3 py-1 rounded bg-[#e5c158]/20 border border-[#e5c158]/40 text-[#e5c158] text-[11px] font-black uppercase tracking-widest">
                  {cat.subtitle}
                </span>

                <h3 className="text-2xl sm:text-3xl font-black uppercase text-white tracking-wide">
                  {cat.title}
                </h3>

                <p className="text-xs text-zinc-300 line-clamp-2 leading-relaxed font-medium">
                  {cat.items}
                </p>

                {/* Direct Shop Now filter button */}
                <button
                  onClick={() => onCategorySelect(cat.id)}
                  className="w-full py-3.5 px-6 rounded-xl bg-white text-black group-hover:bg-[#e5c158] font-black text-xs uppercase tracking-[0.2em] shadow-lg transition-all duration-300 flex items-center justify-center gap-2 transform active:scale-95"
                >
                  <span>SHOP NOW</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ============================================================
          🔥 HOT SELLING SECTION
      ============================================================ */}
      <section className="py-20 bg-[#0d0d10] border-y border-zinc-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <div className="flex items-center gap-2 text-amber-400 text-xs font-black uppercase tracking-[0.25em] mb-2">
                <Flame className="w-4 h-4 fill-current text-amber-500 animate-bounce" />
                <span>Most Wanted Pieces in Ghana</span>
              </div>
              <h2 className="text-3xl sm:text-5xl font-black uppercase tracking-tight text-white font-sans flex items-center gap-3">
                🔥 HOT SELLING
              </h2>
            </div>

            <button
              onClick={() => onNavigateShop()}
              className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-widest text-[#e5c158] hover:text-white transition-colors group"
            >
              <span>View All Products</span>
              <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Hot Selling Products Grid */}
          {loadingHotSelling ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {[1, 2, 3, 4].map((n) => (
                <div key={n} className="bg-zinc-900/60 rounded-xl h-80 animate-pulse border border-zinc-800"></div>
              ))}
            </div>
          ) : hotSellingProducts.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {hotSellingProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onViewDetails={onViewProduct}
                  onAddToCart={onAddToCart}
                  onAskProduct={onAskProduct}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-zinc-900/30 rounded-2xl border border-zinc-800 text-zinc-400">
              <p className="text-sm">Hot selling items are being updated by Mr. J Collections.</p>
              <button
                onClick={() => onNavigateShop()}
                className="mt-4 px-6 py-2.5 bg-white text-black font-bold uppercase text-xs rounded-full"
              >
                Browse Shop
              </button>
            </div>
          )}

        </div>
      </section>

      {/* ============================================================
          BRAND TRUST & ETHOS (NIKE STYLE HIGHLIGHT)
      ============================================================ */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-zinc-950 via-[#121217] to-zinc-950 border border-[#c5a059]/30 p-8 sm:p-14 lg:p-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-[#e5c158]/10 text-[#e5c158] text-xs font-black uppercase tracking-widest border border-[#e5c158]/20">
                <CheckCircle2 className="w-3.5 h-3.5" />
                The Mr. J Standard
              </div>

              <h2 className="text-3xl sm:text-5xl font-black uppercase tracking-tight text-white font-sans leading-tight">
                QUALITY FASHION. <br />
                AFFORDABLE PRICES. <br />
                NATIONWIDE DELIVERY.
              </h2>

              <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
                {BUSINESS_INFO.aboutUsText}
              </p>

              <div className="pt-2 flex flex-wrap gap-4">
                <button
                  onClick={() => onNavigateShop()}
                  className="px-8 py-3.5 bg-white hover:bg-[#e5c158] text-black font-black text-xs uppercase tracking-widest rounded-full transition-all"
                >
                  START SHOPPING
                </button>
                <a
                  href={BUSINESS_INFO.whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-8 py-3.5 bg-zinc-900 hover:bg-zinc-800 text-white border border-zinc-700 font-black text-xs uppercase tracking-widest rounded-full transition-all flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 text-[#25D366]" />
                  <span>TALK TO US</span>
                </a>
              </div>
            </div>

            {/* Visual Logo Emblem */}
            <div className="flex justify-center lg:justify-end">
              <div className="relative w-64 h-64 sm:w-80 sm:h-80 rounded-2xl overflow-hidden border-2 border-[#c5a059]/60 shadow-[0_0_50px_rgba(197,160,89,0.25)] bg-black p-2">
                <img
                  src="/logo.jpg"
                  alt="Mr. J Collections Emblem"
                  className="w-full h-full object-cover rounded-xl"
                />
              </div>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}
