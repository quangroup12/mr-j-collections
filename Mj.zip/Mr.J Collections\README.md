# Mr. J Collections — E-Commerce Website

**Tarkwa's Trusted Fashion Plug | Nationwide Ghana Delivery**

---

## 🚀 Quick Start (Hosting)

### Requirements
- Node.js v18 or higher
- npm v8 or higher

### Steps

```bash
# 1. Extract the zip and open a terminal in the folder
cd "Mr.J Collections"

# 2. Install server dependencies
npm install

# 3. Start the server
npm start
```

The website will be live at: **http://localhost:5000**

---

## 🌐 Deploying to a Live Server (e.g. Render, Railway, VPS)

1. Upload this folder to your server (without node_modules)
2. Run `npm install` on the server
3. Run `npm start` — the server runs on port **5000** by default
4. Set the `PORT` environment variable to change the port:
   ```
   PORT=3000 npm start
   ```

### Environment Variables (Optional)
| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `5000` | Port to run the server on |
| `JWT_SECRET` | auto-generated | Secret for JWT tokens (set a fixed one in production) |

---

## 📁 File Structure

```
Mr.J Collections/
├── server.js          # Main Express backend server
├── db.js              # SQLite database schema & seed data
├── build.js           # esbuild bundler script (for rebuilding frontend)
├── package.json       # Node.js dependencies
├── database.sqlite    # SQLite database (products, users, messages)
├── public/            # Served static files
│   ├── index.html     # Main HTML entry point
│   ├── bundle.js      # Compiled React frontend (pre-built)
│   ├── style.css      # Compiled Tailwind CSS (pre-built)
│   ├── logo.jpg       # Store logo
│   └── hero-bg.jpg    # Hero section background photo
├── uploads/           # Product images uploaded by admin
└── client/src/        # React source code (for rebuilding)
```

---

## 🔑 Admin Login

| Field | Value |
|-------|-------|
| Username | `Joe123collections` |
| Password | `Joe123collections` |

Access the Admin Dashboard from: **Sign In / Join** button in the navbar

---

## 📦 Features

- **Home, Shop, About, Contact** pages
- **Product Search** — search bar in navbar on all devices
- **Shopping Cart** — slide-out drawer with WhatsApp checkout
- **Customer Accounts** — sign up, personal inbox, ask about products
- **Admin Dashboard** — product CRUD, customer chats, enquiries
- **Nationwide Ghana delivery** — WhatsApp order integration
- **Mobile responsive** — works on phones, tablets, desktops

---

## 📞 Business Contact
- **WhatsApp:** 0594326515
- **Location:** Tarkwa, Western Region, Ghana
- **Instagram:** @mr.j.collections
