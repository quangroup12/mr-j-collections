const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db, initDB } = require('./db');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'mr_j_collections_super_secret_jwt_key_2026';

// Ensure uploads folder exists
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, 'mrj-' + uniqueSuffix + ext);
  }
});

const fileFilter = (req, file, cb) => {
  const allowed = /jpeg|jpg|png|webp|gif/;
  const isMimeValid = allowed.test(file.mimetype);
  const isExtValid = allowed.test(path.extname(file.originalname).toLowerCase());
  if (isMimeValid && isExtValid) {
    cb(null, true);
  } else {
    cb(new Error('Only image files (jpeg, jpg, png, webp, gif) are allowed!'));
  }
};

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB per image
  fileFilter
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static uploads
app.use('/uploads', express.static(uploadsDir));

// Initialize DB
initDB();

// JWT Authentication Middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
}

// Helper to parse product JSON fields
function formatProduct(product) {
  if (!product) return null;
  return {
    ...product,
    images: typeof product.images === 'string' ? JSON.parse(product.images || '[]') : (product.images || []),
    sizes: typeof product.sizes === 'string' ? JSON.parse(product.sizes || '[]') : (product.sizes || []),
    colors: typeof product.colors === 'string' ? JSON.parse(product.colors || '[]') : (product.colors || []),
    hotSelling: Boolean(product.hotSelling)
  };
}

/* ============================================================
   AUTH & ADMIN ROUTES
============================================================ */

// Unified Login (Admin & Customers)
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, error: 'Username/Email and password are required' });
  }

  const term = username.trim().toLowerCase();

  // Check users table first
  let user = db.prepare('SELECT * FROM users WHERE LOWER(username) = ? OR LOWER(email) = ? OR phone = ?').get(term, term, term);

  // If not found in users, check admins table
  let role = 'customer';
  if (!user) {
    const admin = db.prepare('SELECT * FROM admins WHERE LOWER(username) = ?').get(term);
    if (admin) {
      user = { ...admin, name: 'Mr. J Store Admin', role: 'admin' };
      role = 'admin';
    }
  } else {
    role = user.role || 'customer';
  }

  if (!user) {
    return res.status(401).json({ success: false, error: 'Account not found. Please check credentials or sign up.' });
  }

  const isMatch = bcrypt.compareSync(password, user.passwordHash);
  if (!isMatch) {
    return res.status(401).json({ success: false, error: 'Incorrect password.' });
  }

  const token = jwt.sign(
    { id: user.id, username: user.username, role, name: user.name || user.username },
    JWT_SECRET,
    { expiresIn: '7d' }
  );

  res.json({
    success: true,
    token,
    user: {
      id: user.id,
      username: user.username,
      name: user.name || user.username,
      phone: user.phone || '',
      email: user.email || '',
      role
    }
  });
});

// Customer Sign Up
app.post('/api/auth/signup', (req, res) => {
  const { name, username, phone, email, password } = req.body;
  if (!name || !username || !password) {
    return res.status(400).json({ success: false, error: 'Full name, username, and password are required' });
  }

  if (password.length < 6) {
    return res.status(400).json({ success: false, error: 'Password must be at least 6 characters long' });
  }

  const cleanUsername = username.trim().toLowerCase();
  const existingUser = db.prepare('SELECT id FROM users WHERE LOWER(username) = ? OR LOWER(email) = ?').get(cleanUsername, cleanUsername);
  const existingAdmin = db.prepare('SELECT id FROM admins WHERE LOWER(username) = ?').get(cleanUsername);

  if (existingUser || existingAdmin) {
    return res.status(400).json({ success: false, error: 'Username or email already in use. Please choose another or login.' });
  }

  const passwordHash = bcrypt.hashSync(password, 10);
  const stmt = db.prepare('INSERT INTO users (name, username, phone, email, passwordHash, role) VALUES (?, ?, ?, ?, ?, ?)');
  const result = stmt.run(name.trim(), cleanUsername, phone ? phone.trim() : null, email ? email.trim() : null, passwordHash, 'customer');

  const token = jwt.sign(
    { id: result.lastInsertRowid, username: cleanUsername, role: 'customer', name: name.trim() },
    JWT_SECRET,
    { expiresIn: '7d' }
  );

  res.status(201).json({
    success: true,
    token,
    user: {
      id: result.lastInsertRowid,
      name: name.trim(),
      username: cleanUsername,
      phone: phone ? phone.trim() : '',
      email: email ? email.trim() : '',
      role: 'customer'
    }
  });
});

// Current User Profile Check
app.get('/api/auth/me', authenticateToken, (req, res) => {
  if (req.user.role === 'admin') {
    const admin = db.prepare('SELECT id, username, createdAt FROM admins WHERE id = ?').get(req.user.id) ||
                  db.prepare('SELECT id, name, username, role, createdAt FROM users WHERE id = ?').get(req.user.id);
    return res.json({ success: true, user: { ...admin, role: 'admin' } });
  }

  const user = db.prepare('SELECT id, name, username, phone, email, role, createdAt FROM users WHERE id = ?').get(req.user.id);
  if (!user) {
    return res.status(404).json({ success: false, error: 'User not found' });
  }
  res.json({ success: true, user });
});

// Backwards-compatible Admin Login
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, error: 'Username and password are required' });
  }

  const admin = db.prepare('SELECT * FROM admins WHERE username = ?').get(username) ||
                db.prepare("SELECT * FROM users WHERE username = ? AND role = 'admin'").get(username);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Invalid credentials' });
  }

  const isMatch = bcrypt.compareSync(password, admin.passwordHash);
  if (!isMatch) {
    return res.status(401).json({ success: false, error: 'Invalid credentials' });
  }

  const token = jwt.sign(
    { id: admin.id, username: admin.username, role: 'admin' },
    JWT_SECRET,
    { expiresIn: '7d' }
  );

  res.json({
    success: true,
    token,
    user: { id: admin.id, username: admin.username, role: 'admin' }
  });
});

// Backwards-compatible Admin Profile Check
app.get('/api/admin/me', authenticateToken, (req, res) => {
  const admin = db.prepare('SELECT id, username, createdAt FROM admins WHERE id = ?').get(req.user.id) ||
                db.prepare("SELECT id, username, createdAt FROM users WHERE id = ? AND role = 'admin'").get(req.user.id);
  if (!admin) {
    return res.status(404).json({ success: false, error: 'Admin not found' });
  }
  res.json({ success: true, user: admin });
});

/* ============================================================
   CUSTOMER <-> ADMIN MESSAGING ROUTES
============================================================ */

// Send Message (Customer inquiring about a product or chatting, or Admin replying)
app.post('/api/messages', authenticateToken, (req, res) => {
  try {
    const { userId: targetUserId, message, productId, productName, productPrice, productImage } = req.body;
    if (!message || !message.trim()) {
      return res.status(400).json({ success: false, error: 'Message cannot be empty' });
    }

    const isSenderAdmin = req.user.role === 'admin';
    const conversationUserId = isSenderAdmin ? targetUserId : req.user.id;

    if (!conversationUserId) {
      return res.status(400).json({ success: false, error: 'Customer User ID is required' });
    }

    const senderRole = isSenderAdmin ? 'admin' : 'customer';
    const senderName = isSenderAdmin ? 'Mr. J Collections (Admin)' : (req.user.name || req.user.username);

    const stmt = db.prepare(`
      INSERT INTO messages (userId, senderRole, senderName, productId, productName, productPrice, productImage, message)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(
      conversationUserId,
      senderRole,
      senderName,
      productId || null,
      productName || null,
      productPrice ? parseFloat(productPrice) : null,
      productImage || null,
      message.trim()
    );

    const createdMsg = db.prepare('SELECT * FROM messages WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ success: true, message: createdMsg });
  } catch (err) {
    console.error('Error sending message:', err);
    res.status(500).json({ success: false, error: 'Failed to send message' });
  }
});

// Get Messages
app.get('/api/messages', authenticateToken, (req, res) => {
  try {
    const isSenderAdmin = req.user.role === 'admin';

    // If customer, fetch their own messages
    if (!isSenderAdmin) {
      const messages = db.prepare('SELECT * FROM messages WHERE userId = ? ORDER BY createdAt ASC').all(req.user.id);
      return res.json({ success: true, messages });
    }

    // If admin and userId query provided, fetch thread for that user
    const { userId } = req.query;
    if (userId) {
      const messages = db.prepare('SELECT * FROM messages WHERE userId = ? ORDER BY createdAt ASC').all(userId);
      const customer = db.prepare('SELECT id, name, username, phone, email FROM users WHERE id = ?').get(userId);
      return res.json({ success: true, customer, messages });
    }

    // If admin and no userId, return list of customer threads with unread count
    const threads = db.prepare(`
      SELECT 
        u.id as userId,
        u.name as userName,
        u.username,
        u.phone,
        m.message as lastMessage,
        m.createdAt as lastMessageAt,
        m.senderRole as lastSenderRole,
        (SELECT COUNT(*) FROM messages WHERE userId = u.id AND senderRole = 'customer' AND isRead = 0) as unreadCount
      FROM users u
      JOIN messages m ON m.id = (
        SELECT id FROM messages WHERE userId = u.id ORDER BY createdAt DESC LIMIT 1
      )
      WHERE u.role != 'admin'
      ORDER BY m.createdAt DESC
    `).all();

    res.json({ success: true, threads });
  } catch (err) {
    console.error('Error fetching messages:', err);
    res.status(500).json({ success: false, error: 'Failed to load messages' });
  }
});

// Mark messages as read
app.put('/api/messages/read', authenticateToken, (req, res) => {
  const isSenderAdmin = req.user.role === 'admin';
  const { userId } = req.body;

  if (isSenderAdmin && userId) {
    db.prepare("UPDATE messages SET isRead = 1 WHERE userId = ? AND senderRole = 'customer'").run(userId);
  } else if (!isSenderAdmin) {
    db.prepare("UPDATE messages SET isRead = 1 WHERE userId = ? AND senderRole = 'admin'").run(req.user.id);
  }

  res.json({ success: true });
});

// Admin Change Password
app.post('/api/admin/change-password', authenticateToken, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ success: false, error: 'Current password and new password are required' });
  }

  if (newPassword.length < 6) {
    return res.status(400).json({ success: false, error: 'New password must be at least 6 characters long' });
  }

  const admin = db.prepare('SELECT * FROM admins WHERE id = ?').get(req.user.id);
  if (!admin) {
    return res.status(404).json({ success: false, error: 'Admin not found' });
  }

  const isMatch = bcrypt.compareSync(currentPassword, admin.passwordHash);
  if (!isMatch) {
    return res.status(400).json({ success: false, error: 'Current password does not match' });
  }

  const newHash = bcrypt.hashSync(newPassword, 10);
  db.prepare('UPDATE admins SET passwordHash = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?').run(newHash, req.user.id);

  res.json({ success: true, message: 'Password changed successfully' });
});

// Admin Dashboard Overview Stats
app.get('/api/admin/stats', authenticateToken, (req, res) => {
  const total = db.prepare('SELECT COUNT(*) as count FROM products').get().count;
  const male = db.prepare("SELECT COUNT(*) as count FROM products WHERE category = 'Male'").get().count;
  const female = db.prepare("SELECT COUNT(*) as count FROM products WHERE category = 'Female'").get().count;
  const unisex = db.prepare("SELECT COUNT(*) as count FROM products WHERE category = 'Unisex'").get().count;
  const hotSelling = db.prepare('SELECT COUNT(*) as count FROM products WHERE hotSelling = 1').get().count;
  const inStock = db.prepare("SELECT COUNT(*) as count FROM products WHERE stockStatus = 'In Stock'").get().count;
  const outOfStock = db.prepare("SELECT COUNT(*) as count FROM products WHERE stockStatus = 'Out of Stock'").get().count;

  res.json({
    success: true,
    stats: {
      total,
      male,
      female,
      unisex,
      hotSelling,
      inStock,
      outOfStock
    }
  });
});

/* ============================================================
   PRODUCT ROUTES
============================================================ */

// Get All Products (with filters, search, sort)
app.get('/api/products', (req, res) => {
  const { category, subcategory, search, hotSelling, sort } = req.query;

  let query = 'SELECT * FROM products WHERE 1=1';
  const params = [];

  if (category && category !== 'All') {
    query += ' AND category = ?';
    params.push(category);
  }

  if (subcategory && subcategory !== 'All') {
    query += ' AND subcategory = ?';
    params.push(subcategory);
  }

  if (hotSelling === 'true' || hotSelling === '1') {
    query += ' AND hotSelling = 1';
  }

  if (search && search.trim() !== '') {
    query += ' AND (name LIKE ? OR description LIKE ? OR subcategory LIKE ?)';
    const term = `%${search.trim()}%`;
    params.push(term, term, term);
  }

  // Sorting
  switch (sort) {
    case 'price-asc':
      query += ' ORDER BY price ASC';
      break;
    case 'price-desc':
      query += ' ORDER BY price DESC';
      break;
    case 'name-asc':
      query += ' ORDER BY name ASC';
      break;
    case 'newest':
    default:
      query += ' ORDER BY createdAt DESC, id DESC';
      break;
  }

  const rows = db.prepare(query).all(...params);
  const formatted = rows.map(formatProduct);

  res.json({ success: true, count: formatted.length, products: formatted });
});

// Get Single Product by ID
app.get('/api/products/:id', (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) {
    return res.status(404).json({ success: false, error: 'Product not found' });
  }

  // Related products from same category
  const related = db.prepare('SELECT * FROM products WHERE category = ? AND id != ? LIMIT 4')
    .all(product.category, product.id)
    .map(formatProduct);

  res.json({
    success: true,
    product: formatProduct(product),
    related
  });
});

// Create New Product (Protected)
app.post('/api/products', authenticateToken, (req, res) => {
  try {
    const {
      name,
      price,
      discountPrice,
      category,
      subcategory,
      description,
      images,
      sizes,
      colors,
      stockStatus,
      hotSelling
    } = req.body;

    if (!name || price === undefined || !category || !subcategory) {
      return res.status(400).json({ success: false, error: 'Name, price, category, and subcategory are required' });
    }

    const imagesJson = typeof images === 'string' ? images : JSON.stringify(images || []);
    const sizesJson = typeof sizes === 'string' ? sizes : JSON.stringify(sizes || []);
    const colorsJson = typeof colors === 'string' ? colors : JSON.stringify(colors || []);
    const isHot = hotSelling ? 1 : 0;
    const stock = stockStatus || 'In Stock';

    const stmt = db.prepare(`
      INSERT INTO products (name, price, discountPrice, category, subcategory, description, images, sizes, colors, stockStatus, hotSelling)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(
      name,
      parseFloat(price),
      discountPrice ? parseFloat(discountPrice) : null,
      category,
      subcategory,
      description || '',
      imagesJson,
      sizesJson,
      colorsJson,
      stock,
      isHot
    );

    const newProduct = db.prepare('SELECT * FROM products WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ success: true, product: formatProduct(newProduct) });
  } catch (err) {
    console.error('Error creating product:', err);
    res.status(500).json({ success: false, error: 'Failed to create product' });
  }
});

// Update Product (Protected)
app.put('/api/products/:id', authenticateToken, (req, res) => {
  try {
    const id = req.params.id;
    const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({ success: false, error: 'Product not found' });
    }

    const {
      name,
      price,
      discountPrice,
      category,
      subcategory,
      description,
      images,
      sizes,
      colors,
      stockStatus,
      hotSelling
    } = req.body;

    const imagesJson = images !== undefined ? (typeof images === 'string' ? images : JSON.stringify(images)) : existing.images;
    const sizesJson = sizes !== undefined ? (typeof sizes === 'string' ? sizes : JSON.stringify(sizes)) : existing.sizes;
    const colorsJson = colors !== undefined ? (typeof colors === 'string' ? colors : JSON.stringify(colors)) : existing.colors;

    const stmt = db.prepare(`
      UPDATE products SET
        name = ?,
        price = ?,
        discountPrice = ?,
        category = ?,
        subcategory = ?,
        description = ?,
        images = ?,
        sizes = ?,
        colors = ?,
        stockStatus = ?,
        hotSelling = ?,
        updatedAt = CURRENT_TIMESTAMP
      WHERE id = ?
    `);

    stmt.run(
      name !== undefined ? name : existing.name,
      price !== undefined ? parseFloat(price) : existing.price,
      discountPrice !== undefined ? (discountPrice ? parseFloat(discountPrice) : null) : existing.discountPrice,
      category !== undefined ? category : existing.category,
      subcategory !== undefined ? subcategory : existing.subcategory,
      description !== undefined ? description : existing.description,
      imagesJson,
      sizesJson,
      colorsJson,
      stockStatus !== undefined ? stockStatus : existing.stockStatus,
      hotSelling !== undefined ? (hotSelling ? 1 : 0) : existing.hotSelling,
      id
    );

    const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    res.json({ success: true, product: formatProduct(updated) });
  } catch (err) {
    console.error('Error updating product:', err);
    res.status(500).json({ success: false, error: 'Failed to update product' });
  }
});

// Delete Product (Protected)
app.delete('/api/products/:id', authenticateToken, (req, res) => {
  const id = req.params.id;
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!existing) {
    return res.status(404).json({ success: false, error: 'Product not found' });
  }

  db.prepare('DELETE FROM products WHERE id = ?').run(id);
  res.json({ success: true, message: 'Product deleted successfully' });
});

/* ============================================================
   FILE UPLOAD ROUTE
============================================================ */
app.post('/api/upload', authenticateToken, upload.array('images', 10), (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ success: false, error: 'No files were uploaded' });
    }

    const urls = req.files.map(f => `/uploads/${f.filename}`);
    res.json({ success: true, urls });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message || 'File upload failed' });
  }
});

/* ============================================================
   ENQUIRY ROUTES
============================================================ */
app.post('/api/enquiries', (req, res) => {
  const { name, phone, message } = req.body;
  if (!name || !phone || !message) {
    return res.status(400).json({ success: false, error: 'Name, phone, and message are required' });
  }

  const stmt = db.prepare('INSERT INTO enquiries (name, phone, message) VALUES (?, ?, ?)');
  const result = stmt.run(name, phone, message);

  res.status(201).json({ success: true, id: result.lastInsertRowid, message: 'Enquiry received successfully' });
});

app.get('/api/admin/enquiries', authenticateToken, (req, res) => {
  const enquiries = db.prepare('SELECT * FROM enquiries ORDER BY createdAt DESC').all();
  res.json({ success: true, enquiries });
});

// Serve Static Public Directory (SPA)
const publicDir = path.join(__dirname, 'public');
if (fs.existsSync(publicDir)) {
  app.use(express.static(publicDir));
  app.use((req, res) => {
    res.sendFile(path.join(publicDir, 'index.html'));
  });
}

// Start Server
app.listen(PORT, () => {
  console.log(`🚀 Mr. J Collections backend server running on http://localhost:${PORT}`);
});
