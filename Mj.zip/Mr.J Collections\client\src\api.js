const API_BASE = '/api';

export const api = {
  // Products
  async getProducts(params = {}) {
    const searchParams = new URLSearchParams();
    if (params.category && params.category !== 'All') searchParams.append('category', params.category);
    if (params.subcategory && params.subcategory !== 'All') searchParams.append('subcategory', params.subcategory);
    if (params.hotSelling) searchParams.append('hotSelling', '1');
    if (params.search) searchParams.append('search', params.search);
    if (params.sort) searchParams.append('sort', params.sort);

    const res = await fetch(`${API_BASE}/products?${searchParams.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch products');
    return res.json();
  },

  async getProductById(id) {
    const res = await fetch(`${API_BASE}/products/${id}`);
    if (!res.ok) throw new Error('Failed to fetch product details');
    return res.json();
  },

  // Auth: Unified Login (Admin & Customers)
  async login(username, password) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Login failed');
    }
    localStorage.setItem('mrj_token', data.token);
    localStorage.setItem('mrj_user', JSON.stringify(data.user));
    return data;
  },

  // Auth: Customer Sign Up
  async signup(name, username, phone, email, password) {
    const res = await fetch(`${API_BASE}/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, username, phone, email, password })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Sign up failed');
    }
    localStorage.setItem('mrj_token', data.token);
    localStorage.setItem('mrj_user', JSON.stringify(data.user));
    return data;
  },

  logout() {
    localStorage.removeItem('mrj_token');
    localStorage.removeItem('mrj_user');
  },

  getToken() {
    return localStorage.getItem('mrj_token');
  },

  getStoredUser() {
    try {
      const u = localStorage.getItem('mrj_user');
      return u ? JSON.parse(u) : null;
    } catch {
      return null;
    }
  },

  async checkAuth() {
    const token = this.getToken();
    if (!token) return null;
    try {
      const res = await fetch(`${API_BASE}/auth/me`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!res.ok) {
        this.logout();
        return null;
      }
      const data = await res.json();
      return data.user;
    } catch {
      return null;
    }
  },

  async checkAdminAuth() {
    const user = await this.checkAuth();
    if (user && user.role === 'admin') {
      return user;
    }
    return null;
  },

  async changePassword(currentPassword, newPassword) {
    const token = this.getToken();
    const res = await fetch(`${API_BASE}/admin/change-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ currentPassword, newPassword })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Failed to change password');
    }
    return data;
  },

  // Admin Dashboard Stats
  async getAdminStats() {
    const token = this.getToken();
    const res = await fetch(`${API_BASE}/admin/stats`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (!res.ok) throw new Error('Failed to load stats');
    return res.json();
  },

  // Admin Product CRUD
  async createProduct(productData) {
    const token = this.getToken();
    const res = await fetch(`${API_BASE}/products`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(productData)
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Failed to create product');
    }
    return data;
  },

  async updateProduct(id, productData) {
    const token = this.getToken();
    const res = await fetch(`${API_BASE}/products/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(productData)
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Failed to update product');
    }
    return data;
  },

  async deleteProduct(id) {
    const token = this.getToken();
    const res = await fetch(`${API_BASE}/products/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Failed to delete product');
    }
    return data;
  },

  // Upload Images
  async uploadImages(files) {
    const token = this.getToken();
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('images', files[i]);
    }

    const res = await fetch(`${API_BASE}/upload`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` },
      body: formData
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Image upload failed');
    }
    return data.urls;
  },

  // Contact Enquiries
  async submitEnquiry(name, phone, message) {
    const res = await fetch(`${API_BASE}/enquiries`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, phone, message })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Failed to submit enquiry');
    }
    return data;
  },

  async getEnquiries() {
    const token = this.getToken();
    const res = await fetch(`${API_BASE}/admin/enquiries`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (!res.ok) throw new Error('Failed to load enquiries');
    return res.json();
  },

  // Customer <-> Admin Personal Inbox Messages
  async sendMessage({ userId, message, productId, productName, productPrice, productImage }) {
    const token = this.getToken();
    const res = await fetch(`${API_BASE}/messages`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ userId, message, productId, productName, productPrice, productImage })
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Failed to send message');
    }
    return data.message;
  },

  async getMessages(userId = null) {
    const token = this.getToken();
    const url = userId ? `${API_BASE}/messages?userId=${userId}` : `${API_BASE}/messages`;
    const res = await fetch(url, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (!res.ok) throw new Error('Failed to load messages');
    return res.json();
  },

  async markMessagesAsRead(userId = null) {
    const token = this.getToken();
    const res = await fetch(`${API_BASE}/messages/read`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ userId })
    });
    return res.json();
  }
};
