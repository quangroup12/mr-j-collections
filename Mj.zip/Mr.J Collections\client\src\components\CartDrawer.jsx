import React from 'react';
import { X, Trash2, ShoppingBag, Plus, Minus, ArrowRight, MessageCircle } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

export default function CartDrawer({ 
  isOpen, 
  onClose, 
  cartItems, 
  onUpdateQty, 
  onRemoveItem, 
  onClearCart,
  onNavigateShop 
}) {
  if (!isOpen) return null;

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  // Generate WhatsApp order message for entire cart
  const handleCheckoutWhatsApp = () => {
    if (cartItems.length === 0) return;

    let msg = `Hello Mr. J Collections, I want to order the following items from my cart:\n\n`;
    cartItems.forEach((item, index) => {
      msg += `${index + 1}. ${item.name}\n`;
      if (item.selectedSize) msg += `   Size: ${item.selectedSize}\n`;
      if (item.selectedColor) msg += `   Color: ${item.selectedColor}\n`;
      msg += `   Qty: ${item.quantity} x GH₵ ${item.price.toLocaleString()} = GH₵ ${(item.price * item.quantity).toLocaleString()}\n\n`;
    });

    msg += `Total Amount: GH₵ ${subtotal.toLocaleString()}\n\nPlease send me the payment details and delivery information.`;

    const url = `https://wa.me/${BUSINESS_INFO.whatsappNumber}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Dark Backdrop */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-xs transition-opacity duration-300"
      ></div>

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#101014] border-l border-zinc-800 text-white shadow-2xl flex flex-col">
          
          {/* Cart Header */}
          <div className="p-5 border-b border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-[#e5c158]">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-black uppercase tracking-wider text-white">
                  YOUR SHOPPING CART
                </h2>
                <p className="text-[11px] text-zinc-400 font-semibold">
                  {cartItems.length} unique item{cartItems.length === 1 ? '' : 's'}
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cartItems.length === 0 ? (
              <div className="text-center py-20 space-y-4">
                <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-500">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="text-base font-black uppercase text-white tracking-wider">
                  Your cart is empty
                </h3>
                <p className="text-xs text-zinc-400 max-w-xs mx-auto">
                  Looks like you haven't added any drip to your bag yet. Explore sneakers, slides, perfumes and more.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onNavigateShop();
                  }}
                  className="px-6 py-3 bg-white hover:bg-[#e5c158] text-black font-black text-xs uppercase tracking-widest rounded-full transition-all"
                >
                  START SHOPPING
                </button>
              </div>
            ) : (
              cartItems.map((item, idx) => (
                <div 
                  key={`${item.id}-${item.selectedSize}-${item.selectedColor}-${idx}`}
                  className="p-3.5 rounded-xl bg-zinc-900/70 border border-zinc-800/80 flex gap-3 group"
                >
                  {/* Item Image */}
                  <div className="w-16 h-20 rounded-lg overflow-hidden bg-zinc-950 border border-zinc-800 shrink-0">
                    <img
                      src={item.image || (item.images && item.images[0]) || '/logo.jpg'}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Item Details */}
                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-white truncate group-hover:text-[#e5c158] transition-colors">
                        {item.name}
                      </h4>
                      
                      <div className="flex flex-wrap gap-2 text-[10px] text-zinc-400 font-medium mt-0.5">
                        {item.selectedSize && (
                          <span className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">
                            Size: {item.selectedSize}
                          </span>
                        )}
                        {item.selectedColor && (
                          <span className="bg-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">
                            Color: {item.selectedColor}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs font-black text-white">
                        GH₵ {(item.price * item.quantity).toLocaleString()}
                      </span>

                      {/* Quantity Controls */}
                      <div className="flex items-center gap-1.5 bg-zinc-950 border border-zinc-800 rounded-lg p-0.5">
                        <button
                          onClick={() => onUpdateQty(idx, item.quantity - 1)}
                          className="p-1 text-zinc-400 hover:text-white transition-colors"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-xs font-bold text-white px-1.5">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQty(idx, item.quantity + 1)}
                          className="p-1 text-zinc-400 hover:text-white transition-colors"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Remove Button */}
                      <button
                        onClick={() => onRemoveItem(idx)}
                        className="p-1 text-zinc-500 hover:text-red-400 transition-colors"
                        title="Remove from cart"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Cart Footer / Checkout */}
          {cartItems.length > 0 && (
            <div className="p-5 border-t border-zinc-800 bg-[#0d0d10] space-y-4">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-zinc-400">
                  <span>Subtotal</span>
                  <span className="font-bold text-white">GH₵ {subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>Delivery in Ghana</span>
                  <span className="text-[#e5c158] font-bold">Nationwide</span>
                </div>
                <div className="flex justify-between text-sm font-black text-white pt-2 border-t border-zinc-800">
                  <span>Estimated Total</span>
                  <span className="text-base text-[#e5c158]">GH₵ {subtotal.toLocaleString()}</span>
                </div>
              </div>

              {/* Order via WhatsApp */}
              <button
                onClick={handleCheckoutWhatsApp}
                className="w-full py-4 px-6 bg-[#25D366] hover:bg-[#20ba59] text-black font-black text-xs uppercase tracking-[0.2em] rounded-xl shadow-xl transition-all duration-300 flex items-center justify-center gap-2 transform active:scale-95"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>ORDER ENTIRE CART VIA WHATSAPP</span>
              </button>

              <div className="flex items-center justify-between text-[11px] text-zinc-500">
                <span>Free delivery coordination</span>
                <button
                  onClick={onClearCart}
                  className="hover:text-red-400 transition-colors"
                >
                  Clear Cart
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
