import React, { useState, useRef } from 'react';
import { 
  Menu, 
  X, 
  ShoppingBag, 
  MessageCircle, 
  ShieldCheck, 
  ChevronRight, 
  User, 
  LogOut, 
  MessageSquare,
  Search
} from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

export default function Navbar({ 
  activePage, 
  setActivePage, 
  onCategorySelect,
  onSearch,
  cartCount = 0,
  onOpenCart,
  currentUser,
  onLogout,
  onOpenAuth
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');
  const searchInputRef = useRef(null);

  const handleNavClick = (pageId, category = null) => {
    setActivePage(pageId);
    if (category && onCategorySelect) {
      onCategorySelect(category);
    }
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    const q = searchValue.trim();
    if (!q) return;
    if (onSearch) onSearch(q);
    setSearchOpen(false);
    setMobileMenuOpen(false);
  };

  const handleSearchIconClick = () => {
    setSearchOpen(true);
    setTimeout(() => searchInputRef.current?.focus(), 50);
  };

  const handleSearchClose = () => {
    setSearchOpen(false);
    setSearchValue('');
  };

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'shop', label: 'Shop' },
    { id: 'about', label: 'About' },
    { id: 'contact', label: 'Contact' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0a0a0c]/95 backdrop-blur-md border-b border-white/10 text-white">
      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand Name */}
          <button 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left group focus:outline-none shrink-0"
          >
            <div className="relative h-12 w-12 rounded-lg overflow-hidden border border-[#c5a059]/40 p-0.5 bg-black shadow-md group-hover:border-[#c5a059] transition-all">
              <img 
                src="/logo.jpg" 
                alt="Mr. J Collections Logo" 
                className="w-full h-full object-cover rounded"
              />
            </div>
            <div>
              <span className="text-xl sm:text-2xl font-black tracking-wider uppercase text-white group-hover:text-[#e5c158] transition-colors block leading-tight font-sans">
                MR. J <span className="text-[#e5c158]">COLLECTIONS</span>
              </span>
              <span className="text-[10px] tracking-[0.25em] text-zinc-400 uppercase block font-medium">
                TARKWA • GHANA
              </span>
            </div>
          </button>

          {/* Desktop Search Overlay / Normal Nav */}
          {searchOpen ? (
            /* Expanded Search Bar */
            <form
              onSubmit={handleSearchSubmit}
              className="flex-1 mx-4 flex items-center gap-2"
            >
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  placeholder="Search sneakers, slides, perfumes, bags, wigs..."
                  className="w-full pl-10 pr-4 py-2.5 bg-zinc-900 border border-[#e5c158]/60 rounded-full text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#e5c158] transition-all"
                />
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 bg-[#e5c158] hover:bg-[#d4af37] text-black font-black text-xs uppercase tracking-wider rounded-full transition-all"
              >
                Search
              </button>
              <button
                type="button"
                onClick={handleSearchClose}
                className="p-2 text-zinc-400 hover:text-white rounded-full hover:bg-zinc-800 transition-colors"
                title="Close search"
              >
                <X className="w-5 h-5" />
              </button>
            </form>
          ) : (
            <>
              {/* Desktop Navigation Links */}
              <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
                {navLinks.map((link) => (
                  <button
                    key={link.id}
                    onClick={() => handleNavClick(link.id)}
                    className={`px-3.5 py-2 text-xs font-bold uppercase tracking-widest transition-all rounded-md relative ${
                      activePage === link.id
                        ? 'text-white'
                        : 'text-zinc-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    {link.label}
                    {activePage === link.id && (
                      <span className="absolute bottom-0 left-3.5 right-3.5 h-0.5 bg-[#e5c158] rounded-full"></span>
                    )}
                  </button>
                ))}
              </nav>

              {/* Right Action Buttons */}
              <div className="hidden sm:flex items-center gap-2">

                {/* Search Icon Button */}
                <button
                  onClick={handleSearchIconClick}
                  className="p-2.5 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-white transition-all"
                  title="Search products"
                >
                  <Search className="w-4 h-4 text-zinc-300" />
                </button>

                {/* Cart Button */}
                <button
                  onClick={onOpenCart}
                  className="relative p-2.5 rounded-full bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 text-white transition-all transform active:scale-95 group"
                  title="Shopping Cart"
                >
                  <ShoppingBag className="w-4 h-4 text-[#e5c158]" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#e5c158] text-black text-[10px] font-black flex items-center justify-center shadow-lg">
                      {cartCount}
                    </span>
                  )}
                </button>

                {/* If Customer Logged In: Personal Inbox Link */}
                {currentUser && currentUser.role === 'customer' && (
                  <button
                    onClick={() => handleNavClick('inbox')}
                    className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold uppercase tracking-wider rounded-full border transition-all ${
                      activePage === 'inbox'
                        ? 'bg-[#e5c158] text-black border-[#e5c158]'
                        : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border-zinc-700/80'
                    }`}
                    title="Your Personal Inbox"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-[#e5c158]" />
                    <span>Inbox</span>
                  </button>
                )}

                {/* Auth / Account Controls */}
                {currentUser ? (
                  <div className="flex items-center gap-2 pl-1 border-l border-zinc-800">
                    {currentUser.role === 'admin' ? (
                      <button
                        onClick={() => handleNavClick('admin-dashboard')}
                        className="px-4 py-2 bg-[#e5c158] hover:bg-[#d4af37] text-black font-black text-xs uppercase tracking-wider rounded-full shadow-md transition-all flex items-center gap-1.5"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>Admin</span>
                      </button>
                    ) : (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleNavClick('inbox')}
                          className="text-xs font-bold text-zinc-300 hover:text-white truncate max-w-[120px]"
                        >
                          Hi, {currentUser.name ? currentUser.name.split(' ')[0] : currentUser.username}
                        </button>
                      </div>
                    )}

                    <button
                      onClick={onLogout}
                      className="p-2 text-zinc-500 hover:text-red-400 rounded-full hover:bg-zinc-900 transition-colors"
                      title="Logout"
                    >
                      <LogOut className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={onOpenAuth}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold uppercase tracking-wider text-zinc-300 hover:text-white bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 rounded-full transition-all"
                  >
                    <User className="w-3.5 h-3.5 text-[#e5c158]" />
                    <span>Sign In / Join</span>
                  </button>
                )}

                {/* Shop Now Action */}
                <button
                  onClick={() => handleNavClick('shop')}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-black uppercase tracking-widest bg-white text-black hover:bg-[#e5c158] hover:text-black rounded-full shadow-lg transition-all transform active:scale-95"
                >
                  <span>SHOP NOW</span>
                </button>
              </div>
            </>
          )}

          {/* Mobile Menu & Quick Cart/Search Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={handleSearchIconClick}
              className="p-2 rounded-full bg-zinc-900 border border-zinc-700 text-white"
              title="Search"
            >
              <Search className="w-4 h-4 text-zinc-300" />
            </button>
            <button
              onClick={onOpenCart}
              className="relative p-2 rounded-full bg-zinc-900 border border-zinc-700 text-white"
            >
              <ShoppingBag className="w-4 h-4 text-[#e5c158]" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#e5c158] text-black text-[9px] font-black flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-800 focus:outline-none transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0d0d10] border-b border-zinc-800 px-4 pt-3 pb-6 space-y-3 animate-in slide-in-from-top duration-200">
          
          {/* Mobile Search Bar */}
          <form onSubmit={handleSearchSubmit} className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
            <input
              type="text"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Search products..."
              className="w-full pl-10 pr-4 py-2.5 bg-zinc-900 border border-zinc-700 rounded-xl text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#e5c158] transition-all"
            />
          </form>

          {/* Account Status in Mobile Drawer */}
          <div className="p-3 rounded-xl bg-zinc-900/90 border border-zinc-800 flex items-center justify-between">
            {currentUser ? (
              <div className="flex items-center justify-between w-full">
                <div className="min-w-0">
                  <p className="text-xs font-bold text-white truncate">
                    {currentUser.name || currentUser.username}
                  </p>
                  <p className="text-[10px] text-[#e5c158] uppercase font-semibold">
                    {currentUser.role === 'admin' ? 'Administrator' : 'Customer Account'}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {currentUser.role === 'customer' && (
                    <button
                      onClick={() => handleNavClick('inbox')}
                      className="px-3 py-1 bg-zinc-800 rounded-lg text-xs font-bold text-white"
                    >
                      Inbox
                    </button>
                  )}
                  {currentUser.role === 'admin' && (
                    <button
                      onClick={() => handleNavClick('admin-dashboard')}
                      className="px-3 py-1 bg-[#e5c158] rounded-lg text-xs font-bold text-black"
                    >
                      Dashboard
                    </button>
                  )}
                  <button
                    onClick={onLogout}
                    className="p-1.5 text-zinc-400 hover:text-red-400"
                    title="Logout"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAuth();
                }}
                className="w-full py-2.5 px-4 bg-white text-black font-black text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-2"
              >
                <User className="w-4 h-4" />
                <span>Sign In / Create Account</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 pb-2">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`flex items-center justify-between p-3 rounded-lg text-sm font-bold uppercase tracking-wider text-left transition-colors ${
                  activePage === link.id
                    ? 'bg-zinc-800 text-[#e5c158] border border-[#e5c158]/30'
                    : 'bg-zinc-900/80 text-zinc-200 hover:bg-zinc-800'
                }`}
              >
                <span>{link.label}</span>
                <ChevronRight className="w-4 h-4 text-zinc-500" />
              </button>
            ))}
          </div>

          {/* Quick Categories in Mobile */}
          <div className="border-t border-zinc-800/80 pt-3">
            <p className="text-[11px] font-semibold text-zinc-400 uppercase tracking-widest px-1 mb-2">
              Shop Categories
            </p>
            <div className="grid grid-cols-3 gap-2">
              {['Male', 'Female', 'Unisex'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => handleNavClick('shop', cat)}
                  className="py-2 px-3 text-xs font-semibold rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-[#e5c158] border border-zinc-800 text-center uppercase tracking-wider"
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* WhatsApp Action Mobile */}
          <div className="pt-2">
            <a
              href={BUSINESS_INFO.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-[#25D366] hover:bg-[#20ba59] text-black font-extrabold text-sm uppercase tracking-wider rounded-lg shadow-md transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Chat on WhatsApp (0594326515)</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
