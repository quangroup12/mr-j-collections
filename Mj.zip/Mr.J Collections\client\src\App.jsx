import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import FloatingWhatsApp from './components/FloatingWhatsApp';
import CartDrawer from './components/CartDrawer';
import AskProductModal from './components/AskProductModal';
import HomePage from './pages/HomePage';
import ShopPage from './pages/ShopPage';
import ProductDetailsPage from './pages/ProductDetailsPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import AuthPage from './pages/AuthPage';
import CustomerInboxPage from './pages/CustomerInboxPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import { api } from './api';

export default function App() {
  const getInitialPage = () => {
    try {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      const path = window.location.pathname.replace(/^\//, '').toLowerCase();
      const target = hash || path;
      if (target.startsWith('product-')) return 'product-details';
      if (['home', 'shop', 'about', 'contact', 'auth', 'login', 'signup', 'inbox', 'admin-dashboard'].includes(target)) {
        if (target === 'login' || target === 'signup') return 'auth';
        return target;
      }
      if (target === 'admin' || target === 'admin-login') return 'auth';
    } catch (e) {}
    return 'home';
  };

  const [activePage, setActivePage] = useState(getInitialPage);
  const [selectedProductId, setSelectedProductId] = useState(() => {
    try {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      const path = window.location.pathname.replace(/^\//, '').toLowerCase();
      const target = hash || path;
      if (target.startsWith('product-')) {
        const id = target.replace('product-', '');
        return parseInt(id, 10) || id;
      }
    } catch (e) {}
    return null;
  });
  const [selectedShopCategory, setSelectedShopCategory] = useState('All');
  const [selectedShopSearch, setSelectedShopSearch] = useState('');
  
  // Hot Selling products cache for Home page
  const [hotSellingProducts, setHotSellingProducts] = useState([]);
  const [loadingHotSelling, setLoadingHotSelling] = useState(true);

  // User Auth state (both admin and customer)
  const [currentUser, setCurrentUser] = useState(() => api.getStoredUser());

  // Shopping Cart state with localStorage persistence
  const [cartItems, setCartItems] = useState(() => {
    try {
      const saved = localStorage.getItem('mrj_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [askModalProduct, setAskModalProduct] = useState(null);

  // Sync cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('mrj_cart', JSON.stringify(cartItems));
    } catch (err) {
      console.error('Failed to save cart to localStorage', err);
    }
  }, [cartItems]);

  // Check URL hash and pathname changes
  useEffect(() => {
    const handleLocationChange = () => {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      const path = window.location.pathname.replace(/^\//, '').toLowerCase();
      const target = hash || path;

      if (target.startsWith('product-')) {
        const id = target.replace('product-', '');
        setSelectedProductId(parseInt(id, 10) || id);
        setActivePage('product-details');
      } else if (target === 'login' || target === 'signup' || target === 'auth') {
        setActivePage('auth');
      } else if (target === 'admin' || target === 'admin-login') {
        setActivePage('auth');
      } else if (['home', 'shop', 'about', 'contact', 'inbox', 'admin-dashboard'].includes(target)) {
        setActivePage(target);
      }
    };

    window.addEventListener('hashchange', handleLocationChange);
    window.addEventListener('popstate', handleLocationChange);
    return () => {
      window.removeEventListener('hashchange', handleLocationChange);
      window.removeEventListener('popstate', handleLocationChange);
    };
  }, []);

  // Check existing session on boot
  useEffect(() => {
    async function verifyAuth() {
      try {
        const user = await api.checkAuth();
        if (user) {
          setCurrentUser(user);
        } else {
          setCurrentUser(null);
        }
      } catch (err) {
        console.error('Auth verification error', err);
      }
    }
    verifyAuth();
  }, []);

  // Load hot selling products for homepage
  const loadHotSelling = async () => {
    try {
      setLoadingHotSelling(true);
      const res = await api.getProducts({ hotSelling: true });
      setHotSellingProducts(res.products || []);
    } catch (err) {
      console.error('Failed to load hot selling:', err);
    } finally {
      setLoadingHotSelling(false);
    }
  };

  useEffect(() => {
    loadHotSelling();
  }, []);

  // Navigation Handlers
  const navigateTo = (page, updateHash = true) => {
    setActivePage(page);
    if (updateHash) {
      window.location.hash = page;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCategorySelectFromHome = (category) => {
    setSelectedShopCategory(category);
    setSelectedShopSearch('');
    navigateTo('shop');
  };

  const handleSearchFromNav = (query) => {
    setSelectedShopSearch(query);
    setSelectedShopCategory('All');
    navigateTo('shop');
  };

  const handleViewProduct = (product) => {
    setSelectedProductId(product.id);
    setActivePage('product-details');
    window.location.hash = `product-${product.id}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToShop = () => {
    navigateTo('shop');
  };

  // Cart Management Handlers
  const handleAddToCart = (product, size = null, color = null) => {
    setCartItems(prev => {
      const existingIdx = prev.findIndex(item => 
        item.id === product.id && 
        item.selectedSize === (size || null) && 
        item.selectedColor === (color || null)
      );

      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx] = {
          ...updated[existingIdx],
          quantity: updated[existingIdx].quantity + 1
        };
        return updated;
      } else {
        const primaryImage = product.images && product.images.length > 0 ? product.images[0] : '/logo.jpg';
        return [...prev, {
          id: product.id,
          name: product.name,
          price: product.price,
          image: primaryImage,
          selectedSize: size || null,
          selectedColor: color || null,
          quantity: 1,
          category: product.category,
          subcategory: product.subcategory
        }];
      }
    });

    // Auto open drawer to confirm addition to customer
    setIsCartOpen(true);
  };

  const handleUpdateCartQty = (index, newQty) => {
    setCartItems(prev => {
      if (newQty <= 0) {
        return prev.filter((_, i) => i !== index);
      }
      const updated = [...prev];
      updated[index] = { ...updated[index], quantity: newQty };
      return updated;
    });
  };

  const handleRemoveFromCart = (index) => {
    setCartItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Ask Product Modal Handler
  const handleOpenAskProduct = (product) => {
    setAskModalProduct(product);
  };

  // Auth Handlers
  const handleLoginSuccess = (user) => {
    setCurrentUser(user);
    if (user.role === 'admin') {
      navigateTo('admin-dashboard');
    } else {
      // If customer came from asking about a product or inbox, take them to inbox
      navigateTo('inbox');
    }
  };

  const handleLogout = () => {
    api.logout();
    setCurrentUser(null);
    navigateTo('home');
  };

  const isAdminDashboard = activePage === 'admin-dashboard' && currentUser && currentUser.role === 'admin';
  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white flex flex-col font-sans selection:bg-[#e5c158] selection:text-black">
      {/* Show Navbar on all non-admin-dashboard pages */}
      {!isAdminDashboard && (
        <Navbar
          activePage={activePage}
          setActivePage={navigateTo}
          onCategorySelect={handleCategorySelectFromHome}
          onSearch={handleSearchFromNav}
          cartCount={totalCartCount}
          onOpenCart={() => setIsCartOpen(true)}
          currentUser={currentUser}
          onLogout={handleLogout}
          onOpenAuth={() => navigateTo('auth')}
        />
      )}

      {/* Main Page Render */}
      <div className="flex-1">
        {activePage === 'home' && (
          <HomePage
            hotSellingProducts={hotSellingProducts}
            loadingHotSelling={loadingHotSelling}
            onNavigateShop={() => {
              setSelectedShopCategory('All');
              setSelectedShopSearch('');
              navigateTo('shop');
            }}
            onCategorySelect={handleCategorySelectFromHome}
            onViewProduct={handleViewProduct}
            onAddToCart={handleAddToCart}
            onAskProduct={handleOpenAskProduct}
          />
        )}

        {activePage === 'shop' && (
          <ShopPage
            initialCategory={selectedShopCategory}
            initialSearch={selectedShopSearch}
            onViewProduct={handleViewProduct}
            onAddToCart={handleAddToCart}
            onAskProduct={handleOpenAskProduct}
          />
        )}

        {activePage === 'product-details' && selectedProductId && (
          <ProductDetailsPage
            productId={selectedProductId}
            onBack={handleBackToShop}
            onViewProduct={handleViewProduct}
            onAddToCart={handleAddToCart}
            onAskProduct={handleOpenAskProduct}
          />
        )}

        {activePage === 'about' && (
          <AboutPage
            onNavigateShop={() => {
              setSelectedShopCategory('All');
              navigateTo('shop');
            }}
          />
        )}

        {activePage === 'contact' && (
          <ContactPage />
        )}

        {/* Unified Portal (Login & Sign Up for Admin and Customers) */}
        {activePage === 'auth' && (
          currentUser ? (
            currentUser.role === 'admin' ? (
              <AdminDashboardPage
                onLogout={handleLogout}
                onNavigatePublic={() => navigateTo('home')}
              />
            ) : (
              <CustomerInboxPage
                user={currentUser}
                onBackToShop={() => navigateTo('shop')}
                onViewProduct={handleViewProduct}
              />
            )
          ) : (
            <AuthPage
              onLoginSuccess={handleLoginSuccess}
              onCancel={() => navigateTo('home')}
            />
          )
        )}

        {/* Customer Inbox Page */}
        {activePage === 'inbox' && (
          currentUser ? (
            currentUser.role === 'admin' ? (
              <AdminDashboardPage
                onLogout={handleLogout}
                onNavigatePublic={() => navigateTo('home')}
              />
            ) : (
              <CustomerInboxPage
                user={currentUser}
                onBackToShop={() => navigateTo('shop')}
                onViewProduct={handleViewProduct}
              />
            )
          ) : (
            <AuthPage
              onLoginSuccess={handleLoginSuccess}
              onCancel={() => navigateTo('home')}
            />
          )
        )}

        {/* Admin Dashboard */}
        {activePage === 'admin-dashboard' && (
          currentUser && currentUser.role === 'admin' ? (
            <AdminDashboardPage
              onLogout={handleLogout}
              onNavigatePublic={() => {
                loadHotSelling(); // Refresh homepage hot selling on returning
                navigateTo('home');
              }}
            />
          ) : (
            <AuthPage
              onLoginSuccess={handleLoginSuccess}
              onCancel={() => navigateTo('home')}
            />
          )
        )}
      </div>

      {/* Slide-out Shopping Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQty={handleUpdateCartQty}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onNavigateShop={() => {
          setIsCartOpen(false);
          navigateTo('shop');
        }}
      />

      {/* Ask About Product Modal */}
      <AskProductModal
        isOpen={!!askModalProduct}
        onClose={() => setAskModalProduct(null)}
        product={askModalProduct}
        user={currentUser}
        onRequireAuth={() => {
          setAskModalProduct(null);
          navigateTo('auth');
        }}
        onMessageSent={() => {
          setAskModalProduct(null);
          navigateTo('inbox');
        }}
      />

      {/* Floating WhatsApp Button on every customer page */}
      {!isAdminDashboard && (
        <FloatingWhatsApp />
      )}

      {/* Footer on all non-admin-dashboard pages */}
      {!isAdminDashboard && (
        <Footer
          setActivePage={navigateTo}
          onCategorySelect={handleCategorySelectFromHome}
        />
      )}
    </div>
  );
}
