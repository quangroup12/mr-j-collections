import { MessageCircle, MapPin, Phone, ArrowUpRight } from 'lucide-react';
import { BUSINESS_INFO } from '../constants';

const InstagramIcon = ({ className = "w-4 h-4 text-[#e5c158]" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
  </svg>
);

export default function Footer({ setActivePage, onCategorySelect }) {
  const handleNavClick = (pageId, category = null) => {
    setActivePage(pageId);
    if (category && onCategorySelect) {
      onCategorySelect(category);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#070709] border-t border-zinc-800/80 text-zinc-400 text-sm">
      {/* Upper Footer / Brand Statement */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-lg overflow-hidden border border-[#c5a059]/50 bg-black p-0.5">
                <img src="/logo.jpg" alt="Mr. J Collections" className="w-full h-full object-cover rounded" />
              </div>
              <div>
                <h3 className="text-xl font-black uppercase tracking-wider text-white">
                  MR. J <span className="text-[#e5c158]">COLLECTIONS</span>
                </h3>
                <p className="text-[11px] text-[#e5c158] uppercase tracking-widest font-semibold">
                  Tarkwa, Ghana
                </p>
              </div>
            </div>

            <p className="text-zinc-300 text-base font-medium max-w-sm">
              Quality fashion. Affordable prices. Nationwide delivery.
            </p>
            <p className="text-xs text-zinc-400 leading-relaxed max-w-md">
              Your trusted fashion plug in Tarkwa. We sell quality and affordable male, female and unisex fashion items. Original drip delivered straight to your doorstep across Ghana.
            </p>

            {/* Quick Contact Pill */}
            <div className="pt-2">
              <a
                href={BUSINESS_INFO.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/40 text-[#25D366] rounded-full text-xs font-bold uppercase tracking-wider transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat via WhatsApp: 0594326515</span>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-[0.2em] text-white">
              Navigation
            </h4>
            <ul className="space-y-2.5 text-sm">
              {['Home', 'Shop', 'About', 'Contact'].map((item) => (
                <li key={item}>
                  <button
                    onClick={() => handleNavClick(item.toLowerCase())}
                    className="hover:text-white transition-colors flex items-center gap-1 group text-left"
                  >
                    <span>{item}</span>
                    <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-[#e5c158]" />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-[0.2em] text-white">
              Categories
            </h4>
            <ul className="space-y-2.5 text-sm">
              {['Male', 'Female', 'Unisex'].map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => handleNavClick('shop', cat)}
                    className="hover:text-white transition-colors flex items-center gap-1 group text-left"
                  >
                    <span>{cat} Collection</span>
                    <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-[#e5c158]" />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-[0.2em] text-white">
              Contact & Location
            </h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-2.5 text-zinc-300">
                <MapPin className="w-4 h-4 text-[#e5c158] mt-0.5 shrink-0" />
                <span>Tarkwa, Western Region, Ghana</span>
              </div>
              <div className="flex items-center gap-2.5 text-zinc-300">
                <Phone className="w-4 h-4 text-[#e5c158] shrink-0" />
                <span>0594326515</span>
              </div>
              <div className="flex items-center gap-2.5 text-zinc-300">
                <InstagramIcon className="w-4 h-4 text-[#e5c158] shrink-0" />
                <span>@mr.j.collections</span>
              </div>
              <div className="pt-1">
                <span className="inline-block text-[11px] font-semibold text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 px-2.5 py-1 rounded">
                  ✓ Nationwide Delivery Available
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Bottom Legal / Copyright Bar */}
      <div className="border-t border-zinc-900 bg-black/60 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-center text-xs text-zinc-500">
          <p>© 2026 Mr. J Collections. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
