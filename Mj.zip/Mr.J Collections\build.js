const esbuild = require('esbuild');
const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');

async function build() {
  const publicDir = path.join(__dirname, 'public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  // Copy logo to public
  const logoSrc = path.join(__dirname, 'uploads', 'logo.jpg');
  const logoDest = path.join(publicDir, 'logo.jpg');
  if (fs.existsSync(logoSrc)) {
    fs.copyFileSync(logoSrc, logoDest);
  }

  console.log('⚡ Compiling CSS with Tailwind CLI...');
  try {
    execSync('npx @tailwindcss/cli -i client/src/index.css -o public/style.css', { stdio: 'inherit' });
    console.log('✅ CSS compiled successfully into public/style.css');
  } catch (err) {
    console.warn('⚠️ Tailwind CLI error (will fallback to CDN if needed):', err.message);
  }

  console.log('⚡ Bundling client with esbuild (automatic JSX runtime)...');
  try {
    await esbuild.build({
      entryPoints: [path.join(__dirname, 'client', 'src', 'main.jsx')],
      bundle: true,
      outfile: path.join(publicDir, 'bundle.js'),
      minify: true,
      sourcemap: false,
      jsx: 'automatic', // Fixes "ReferenceError: React is not defined"
      loader: {
        '.js': 'jsx',
        '.jsx': 'jsx',
        '.css': 'empty'
      },
      define: {
        'process.env.NODE_ENV': '"production"'
      },
      target: ['es2020']
    });

    console.log('✅ Client bundled successfully into public/bundle.js');
  } catch (err) {
    console.error('❌ Build failed:', err);
    process.exit(1);
  }
}

build();
