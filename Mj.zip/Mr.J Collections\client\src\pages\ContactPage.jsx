import React, { useState } from 'react';
import { 
  MessageCircle, 
  MapPin, 
  Phone, 
  Send, 
  CheckCircle2, 
  Clock, 
  Truck, 
  AlertCircle 
} from 'lucide-react';
import { BUSINESS_INFO, createEnquiryWhatsAppUrl } from '../constants';
import { api } from '../api';

const InstagramIcon = ({ className = "w-5 h-5" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
  </svg>
);

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    message: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.message) {
      setError('Please fill in your name, phone number, and message.');
      return;
    }

    try {
      setSubmitting(true);
      setError(null);
      await api.submitEnquiry(formData.name, formData.phone, formData.message);
      setSuccess(true);
      setFormData({ name: '', phone: '', message: '' });
    } catch (err) {
      setError(err.message || 'Failed to submit enquiry. Please try WhatsApp directly.');
    } finally {
      setSubmitting(false);
    }
  };

  const directWhatsAppUrl = createEnquiryWhatsAppUrl();

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-16">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <p className="text-xs font-black uppercase tracking-[0.25em] text-[#e5c158]">
            Get In Touch
          </p>
          <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-sans">
            CONTACT MR. J
          </h1>
          <p className="text-zinc-400 text-sm sm:text-base">
            We are ready to assist with sizing, order inquiries, product availability, and nationwide delivery across Ghana.
          </p>
        </div>

        {/* Contact Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* LEFT: Business Info & Prominent WhatsApp (5 cols on LG) */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="p-8 rounded-3xl bg-[#111116] border border-zinc-800 shadow-2xl space-y-6">
              
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-xl overflow-hidden border border-[#c5a059] bg-black p-0.5">
                  <img src="/logo.jpg" alt="Mr. J Collections" className="w-full h-full object-cover rounded-lg" />
                </div>
                <div>
                  <h3 className="text-xl font-black uppercase tracking-wider text-white">
                    {BUSINESS_INFO.name}
                  </h3>
                  <p className="text-xs text-[#e5c158] font-bold uppercase tracking-widest">
                    Tarkwa, Ghana
                  </p>
                </div>
              </div>

              {/* Direct Info List */}
              <div className="space-y-4 pt-2 border-t border-zinc-800/80 text-sm">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-[#e5c158]">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-zinc-500 font-bold">Location</p>
                    <p className="text-zinc-200 font-medium">{BUSINESS_INFO.location}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-[#e5c158]">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-zinc-500 font-bold">Phone / WhatsApp</p>
                    <p className="text-zinc-200 font-medium">{BUSINESS_INFO.phone}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-[#e5c158]">
                    <InstagramIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-zinc-500 font-bold">Social Media</p>
                    <p className="text-zinc-200 font-medium">{BUSINESS_INFO.socialMedia}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-[#e5c158]">
                    <Truck className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-zinc-500 font-bold">Delivery</p>
                    <p className="text-zinc-200 font-medium">{BUSINESS_INFO.delivery}</p>
                  </div>
                </div>
              </div>

              {/* Prominent WhatsApp CTA as requested */}
              <div className="pt-4 border-t border-zinc-800/80 space-y-2">
                <p className="text-[11px] uppercase tracking-wider text-zinc-400 font-bold text-center">
                  Primary & Fastest Ordering Method:
                </p>

                <a
                  href={directWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-4 px-6 bg-[#25D366] hover:bg-[#20ba59] text-black font-black text-sm uppercase tracking-[0.2em] rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 transform active:scale-95"
                >
                  <MessageCircle className="w-5 h-5 fill-current" />
                  <span>CHAT ON WHATSAPP</span>
                </a>
              </div>

            </div>

            {/* Operating Notice Card */}
            <div className="p-6 rounded-2xl bg-zinc-950 border border-zinc-800/80 space-y-2 text-xs text-zinc-400">
              <div className="flex items-center gap-2 text-white font-bold uppercase tracking-wider">
                <Clock className="w-4 h-4 text-[#e5c158]" />
                <span>Quick Response Time</span>
              </div>
              <p>
                Our WhatsApp line is active daily. When you place an order, our team sends product videos, sizing verification, and payment details immediately.
              </p>
            </div>

          </div>

          {/* RIGHT: Enquiry Form (7 cols on LG) */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-10 rounded-3xl bg-[#111116] border border-zinc-800 shadow-2xl space-y-6">
              
              <div>
                <h3 className="text-2xl font-black uppercase tracking-wider text-white">
                  Send An Enquiry
                </h3>
                <p className="text-xs text-zinc-400 mt-1">
                  Fill out this form if you have custom requests or need bulk orders.
                </p>
              </div>

              {success && (
                <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800 text-emerald-300 flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div className="text-xs">
                    <p className="font-bold uppercase tracking-wider">Enquiry Sent Successfully!</p>
                    <p className="text-emerald-400">Thank you! We will reply to your phone number shortly.</p>
                  </div>
                </div>
              )}

              {error && (
                <div className="p-4 rounded-xl bg-red-950/40 border border-red-800 text-red-300 flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
                  <p className="text-xs">{error}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                
                {/* Name */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter your full name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-[#e5c158] transition-all"
                  />
                </div>

                {/* Phone Number */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    Phone / WhatsApp Number *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 0594326515 or 024XXXXXXX"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-[#e5c158] transition-all"
                  />
                </div>

                {/* Message */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    Message / Question *
                  </label>
                  <textarea
                    rows={5}
                    required
                    placeholder="Tell us what product or size you are looking for..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full py-3 px-4 rounded-xl bg-zinc-900 border border-zinc-700/80 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-[#e5c158] transition-all resize-none"
                  ></textarea>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-4 px-6 bg-white hover:bg-[#e5c158] disabled:bg-zinc-800 text-black font-black text-xs uppercase tracking-[0.2em] rounded-xl transition-all shadow-xl flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>{submitting ? 'SENDING...' : 'SUBMIT ENQUIRY'}</span>
                </button>

                <p className="text-[11px] text-zinc-500 text-center">
                  Prefer an instant answer? Chat with us directly on WhatsApp using the button on the left.
                </p>

              </form>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
